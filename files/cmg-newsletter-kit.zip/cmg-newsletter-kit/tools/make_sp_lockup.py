"""SubPrime masthead as one image, the same treatment AR Today got.

Eric, 2026-11-11: "do the same with the SubPrime header". The flag had the
SubPrime wordmark on the left and "News Update" pinned to the right edge, with
the same gap across the page CMG objected to on AR Today.

One image: the SubPrime wordmark (SP500-reverse.png, 700x154, white) with
"News Update" in Oswald Bold right beside it, its capitals as tall as the
wordmark's lowercase letters and on the same baseline, one gap of 0.154 cap heights (the
proportion of the AR wordmark's own word space). "Auto Finance News" stays
under the wordmark, in the same proportion to it as before. The image fills
the 602px content column.

The wordmark is drawn below 1x of its 700px source on the 2x canvas, so it
is downscaled, never enlarged; the script fails if that ever changes.
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from paths import BASE, CHROME, PORT
import pathlib, re, subprocess, sys
import numpy as np
from PIL import Image

SCR = pathlib.Path(__file__).resolve().parent
SERVE = SCR / "serve"
OUT = SCR / "lockup"
OUT.mkdir(exist_ok=True)

LOGO_DIRS = [SERVE / "splogos", SCR / "preview" / "splogos", BASE / "subprime" / "logos"]

BLUE, SUBLINE = "#4da3dd", "#8ec7ec"

# measured from SP500-reverse.png: the P runs rows 2-151, so the cap top is
# row 2 and the baseline row 152
WM_TOP, WM_BASE = 2, 152
WM_CAP = WM_BASE - WM_TOP
WM_SPACE = round(0.154 * WM_CAP)
DISPLAY_W, SCALE = 602, 2
# "News Update" is two words, so at AR's 85% it shrank the wordmark below its
# old 300px. Its capitals match the wordmark's lowercase height instead
# (rows 45-151 in the source), which keeps SubPrime the dominant word.
WM_XTOP = 45
TODAY_SIZE = (WM_BASE - WM_XTOP) / WM_CAP
# "Auto Finance News" was 12px Oswald 500, 3px tracking, under a 300px
# wordmark, its cap top ~17px below the wordmark baseline: keep those ratios
SUB_FONT, SUB_TRACK, SUB_GAP, SUB_REF_W = 12, 3, 17, 300
BIG = 400


def chrome(*args):
    return subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars",
                           "--virtual-time-budget=45000", *args],
                          capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180)


def render_text(text, weight, colour, track_em=0.0, upper=False):
    """Render text in Oswald at BIG px; return (crop, cap height, ascent above baseline)."""
    sample = text.upper() if upper else text
    html = f"""<!doctype html><meta charset=utf-8>
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@{weight}&display=block" rel="stylesheet">
<style>html,body{{margin:0;padding:0;background:transparent}}
#t{{display:inline-block;padding:120px 40px;font-family:'Oswald';font-size:{BIG}px;line-height:{BIG}px;
font-weight:{weight};color:{colour};white-space:nowrap;letter-spacing:{track_em}em}}</style>
<div id=t>{sample}</div><pre id=r style="position:absolute;left:-9999px"></pre>
<script>document.fonts.load("{weight} {BIG}px Oswald").then(function(){{
var ok = document.fonts.check("{weight} {BIG}px Oswald");
var c = document.createElement("canvas").getContext("2d"); c.font = "{weight} {BIG}px Oswald";
var m = c.measureText("H"), w = c.measureText({sample!r});
document.getElementById("r").textContent = (ok ? "FONT_OK" : "FONT_MISSING") +
  " CAP=" + m.actualBoundingBoxAscent + " ASC=" + w.actualBoundingBoxAscent;}});</script>"""
    (SERVE / "lockupimg.html").write_text(html, encoding="utf-8")
    url = f"http://127.0.0.1:{PORT}/lockupimg.html"
    dom = chrome("--window-size=9000,700", "--dump-dom", url).stdout
    assert "FONT_OK" in dom, f"{text}: Oswald did not load, refusing to bake a fallback"
    cap, asc = (float(v) for v in re.search(r"CAP=([\d.]+) ASC=([\d.]+)", dom).groups())
    raw = OUT / f"raw-sp-{abs(hash(text)) % 10000}.png"
    chrome("--default-background-color=00000000", "--window-size=9000,700", f"--screenshot={raw}", url)
    im = Image.open(raw).convert("RGBA")
    box = im.getbbox()
    assert box and box[0] > 0 and box[1] > 0 and box[2] < im.width and box[3] < im.height, f"{text}: ink at edge {box}"
    return im.crop(box), cap, asc


wm = Image.open(SCR / "serve" / "img" / "SP500-reverse.png").convert("RGBA")
head, h_cap, h_asc = render_text("News Update", 700, BLUE)
sub, s_cap, s_asc = render_text("Auto Finance News", 500, SUBLINE, SUB_TRACK / SUB_FONT, upper=True)

# k: source wordmark px -> 2x canvas px, chosen so the row fills DISPLAY_W
r_unit = WM_CAP * TODAY_SIZE / h_cap                     # head scale per unit k
k = (DISPLAY_W - 1) * SCALE / (wm.width + WM_SPACE + head.width * r_unit)
assert k <= 1, f"wordmark would be enlarged ({k:.2f}x)"
w2 = wm.resize((round(wm.width * k), round(wm.height * k)), Image.LANCZOS)
r = r_unit * k
h2 = head.resize((round(head.width * r), round(head.height * r)), Image.LANCZOS)

wm_disp = w2.width / SCALE                               # wordmark width at display size
sub_px = SUB_FONT * wm_disp / SUB_REF_W * SCALE          # subline font size on the 2x canvas
rs = sub_px / BIG
s2 = sub.resize((round(sub.width * rs), round(sub.height * rs)), Image.LANCZOS)

base = WM_BASE * k                                       # wordmark baseline on the canvas
top_h = round(base - h_asc * r)
# the subline is all capitals, so its crop starts at the cap top
sub_top = round(base + SUB_GAP * wm_disp / SUB_REF_W * SCALE)
y0 = min(0, top_h)
H = max(w2.height, top_h + h2.height, sub_top + s2.height) - y0
gap = round(WM_SPACE * k)
W = w2.width + gap + h2.width
canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
canvas.alpha_composite(w2, (0, -y0))
canvas.alpha_composite(h2, (w2.width + gap, top_h - y0))
canvas.alpha_composite(s2, (round(3 * k), sub_top - y0))  # the S's left side bearing
canvas = canvas.crop((0, 0, W + W % 2, H + H % 2))
assert canvas.width // 2 <= DISPLAY_W, "wider than the content column"
name = "SubPrime-masthead.png"
canvas.save(OUT / name, optimize=True)
for d in LOGO_DIRS:
    d.mkdir(parents=True, exist_ok=True)
    canvas.save(d / name, optimize=True)
print(f"wordmark {wm_disp:.0f}px wide at display size (source drawn at {k:.2f}x on the 2x canvas)")
print(name, "2x", canvas.size, "displays", (canvas.width // 2, canvas.height // 2),
      (OUT / name).stat().st_size // 1024, "kB")
