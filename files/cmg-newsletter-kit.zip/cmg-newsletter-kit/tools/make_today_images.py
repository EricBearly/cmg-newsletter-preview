"""Render the masthead's "Today" and "Today pm" to transparent PNGs.

Oswald is a web font and Gmail and desktop Outlook will not load it, so readers
there saw Today in Arial. An image looks the same everywhere. The alt text and
its inline styling carry the word when images are off.

Each image is the 56px line box plus PAD above and below, so it centres in the
masthead exactly where the live text did and the descender of the y, which
runs below the line box, is not clipped. Only the sides are trimmed. The render fails loudly if Oswald did not load, because a fallback
face would otherwise be baked permanently into the artwork.
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from paths import BASE, CHROME, PORT
import pathlib, re, subprocess, sys
from PIL import Image

SCR = pathlib.Path(__file__).resolve().parent
SERVE = SCR / "serve"

FONT_PX, COLOUR, PAD = 56, "#f57c29", 10
BOX = FONT_PX + PAD * 2
PM = '<span style="font-size:0.52em;letter-spacing:1px;">&nbsp;pm</span>'

JOBS = {"today-orange": "Today", "today-pm-orange": "Today" + PM}
OUT_DIRS = [SERVE / "logos", SCR / "preview" / "logos",
            BASE / "logos"]


def page(inner, check_only=False):
    script = """<script>document.fonts.load("700 56px Oswald").then(function(){
      document.title = document.fonts.check("700 56px Oswald") ? "FONT_OK" : "FONT_MISSING";
      document.getElementById("r").textContent = document.title;});</script>"""
    return f"""<!doctype html><meta charset=utf-8>
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@700&display=block" rel="stylesheet">
<style>html,body{{margin:0;padding:0;background:transparent}}
#t{{display:inline-block;padding:{PAD}px 12px;font-family:'Oswald';font-size:{FONT_PX}px;line-height:{FONT_PX}px;
font-weight:700;color:{COLOUR};letter-spacing:-0.5px;white-space:nowrap}}</style>
<div id=t>{inner}</div><pre id=r style="position:absolute;left:-9999px"></pre>{script}"""


def chrome(*args):
    return subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars",
                           "--virtual-time-budget=45000", *args],
                          capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180)


sizes = {}
for name, inner in JOBS.items():
    (SERVE / "todayimg.html").write_text(page(inner), encoding="utf-8")
    url = f"http://127.0.0.1:{PORT}/todayimg.html"
    dom = chrome("--window-size=500,100", "--dump-dom", url).stdout
    assert "FONT_OK" in dom, f"{name}: Oswald did not load, refusing to bake a fallback font"
    raw = SCR / f"{name}-raw.png"
    chrome("--force-device-scale-factor=2", "--default-background-color=00000000",
           f"--window-size=500,{BOX}", f"--screenshot={raw}", url)
    im = Image.open(raw).convert("RGBA")
    box = im.getbbox()
    assert box, f"{name}: render came out empty"
    assert box[1] > 0 and box[3] < BOX * 2, f"{name}: ink touches the edge {box}, it would clip"
    cropped = im.crop((box[0], 0, box[2], BOX * 2))
    assert cropped.getpixel((0, 0))[3] == 0, f"{name}: background is not transparent"
    for d in OUT_DIRS:
        d.mkdir(parents=True, exist_ok=True)
        cropped.save(d / f"{name}.png", optimize=True)
    sizes[name] = (cropped.width // 2 + cropped.width % 2, BOX)
    print(name, "2x", cropped.size, "displays", sizes[name],
          (OUT_DIRS[0] / f"{name}.png").stat().st_size // 1024, "kB")
