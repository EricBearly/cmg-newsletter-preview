# CMG newsletter kit

Everything a developer needs to keep building Cherokee Media Group's e-newsletters,
with or without Claude.

## Using it with Claude

**Claude Code:** unzip to a short path such as `C:\dev\cmg-kit`, then open that
folder in Claude Code. `CLAUDE.md` and the skill in `.claude/skills/cmg-newsletter/`
are picked up from there.

**Other Claude apps:** upload `.claude/skills/cmg-newsletter/` as a custom skill if
your plan allows it, and share `docs/` as project files. The skill points to those
docs by path, and the tools need a machine that can run them.

A good first prompt: *"Read the cmg-newsletter skill, then run the tools and show
me AR Today at desktop and mobile width."*

## Running the tools

You need Python 3.10 or later, Google Chrome, and internet access (Chrome loads web
fonts from Google).

```bash
pip install -r tools/requirements.txt
python tools/run_all.py
```

This rebuilds the editions, captures, PDFs and templates, then runs the checks. It
starts its own local web server on port 8782; set `CMG_PORT` to change that, and
`CHROME` if Chrome isn't found. Output goes to `newsletters/`.

## What's here

| Path | What it is |
|---|---|
| `docs/wordpress-builder-notes.md` | Notes for an optional WordPress builder. **Not built yet.** |
| `docs/template-fields.md` | Every merge field, and how ads disappear |
| `docs/design-rules.md` | The client's settled design decisions |
| `docs/ad-specs.md` | Ad sizes, file limits and character counts |
| `docs/lessons-learned.md` | Mistakes already made once |
| `newsletters/versions/` | HTML for AR Today AM and PM, AR Canada, BHPH Report and Auto Fin Journal |
| `newsletters/subprime/versions/` | HTML for SubPrime |
| `newsletters/templates/` | Merge-field templates for AR Today AM, AR Today PM and SubPrime |
| `newsletters/logos/` | Masthead art |
| `brand/` | The stacked AR mark as SVG, PDF and PNG |
| `tools/` | Scripts and sample assets |

## Tools

| Script | Does |
|---|---|
| `run_all.py` | Runs everything in order |
| `build_pm.py` | Builds AR Today PM from the AM master |
| `build_edition.py` | Builds AR Canada, BHPH Report and Auto Fin Journal |
| `rebuild_six.py` | Measures and captures all six |
| `make_chosen_pdfs.py` | Builds the desktop-then-mobile PDFs |
| `build_templates.py` | Turns the finished samples into merge-field templates |
| `verify_templates.py` | Renders each template with ads sold and unsold, and checks the result |
| `audit_links.py` | Fails if a story block links to two different articles |
| `make_lockup.py` | Regenerates the AR Today AM and PM masthead images. Run it with `python tools/run_all.py --with-art` |
| `make_sp_lockup.py` | Regenerates the SubPrime masthead image. Also run by `--with-art` |
| `mustache.py` | Small reference renderer, used for the checks |

## Know before you start

- **Sample copy is real.** Stories and ads are from live publications and are there to show layout. Sponsor names and logos belong to those sponsors.
- **The stacked AR mark came from the 2026 print media kit,** not from Cherokee's brand files. Ask them for the official master.
- **Hosted art:** the masthead images must be hosted and their `src` updated before a real send. See `docs/template-fields.md`.
- **Not in this package:** pricing, the rate sheet, list data, credentials and the Modern Public Fleet code.
- **Templates:** AR Canada, BHPH Report and Auto Fin Journal have finished samples but no merge-field templates yet.
