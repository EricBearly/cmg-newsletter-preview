# CMG newsletter kit

Templates, tools and notes for Cherokee Media Group's e-newsletters. Use the
`cmg-newsletter` skill in `.claude/skills/` for any work here. If skills aren't
loaded, read `.claude/skills/cmg-newsletter/SKILL.md` directly and follow it.

Rebuild and check everything with `python tools/run_all.py`.

The design rules in `docs/design-rules.md` are settled decisions from the client.
Never invent copy, prices or terms. Never send real email unless asked.
