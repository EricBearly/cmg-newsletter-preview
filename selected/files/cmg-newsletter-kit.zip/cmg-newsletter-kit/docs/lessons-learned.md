# Lessons learned

Mistakes made while building these newsletters, and how to avoid repeating them.

## Rendering and checking
- **Measure geometry, don't copy it.** Hand-copied heights once left 350px of dead space under a mobile capture. `rebuild_six.py` reads heights from the DOM.
- **Look at the result.** A "blank page" complaint was first answered with measurements that looked fine. Rendering the PDF to an image showed the real problem straight away.
- **Web fonts can silently fall back.** One capture came out with "Today" in Arial and nothing reported it. Check any render by eye, and never bake artwork without confirming the font loaded. `make_lockup.py` refuses to.
- **A line box isn't the ink.** Capturing "Today" at its 56px line height cut off the tail of the y. The script now fails if ink touches the edge.
- **Mobile captures need a fixed-width iframe.** Setting a narrow window on headless Chrome directly lays the page out wider and clips it, which looks like a responsive bug that isn't there.
- **Test the breakpoint at both sides.** `max-width:650px` fired at exactly 650 and gave desktop clients the mobile layout. It's now 649px.
- **Shrinking an image doesn't shrink its table cell.** On mobile the logo got smaller while its fixed-width cell didn't, which left a wide gap. Add a mobile rule for the cell too.

## Building from a sample
- **Replacing only the first match is a trap.** A lead story's URL appears three times: headline, picture and Read more. Replacing once left four editions linking pictures to the wrong article. `audit_links.py` now fails if a story block holds two different article links.
- **Regexes can fail silently.** A body-copy pattern that matched nothing left AR Today's copy under other titles' headlines. Assert that a replacement happened.
- **Don't assume attribute order.** Patterns expecting `class` before `src` missed tags repeatedly. Rewrite the whole tag instead.
- **Content modules drift from the files.** A later fix can change a file without updating its module. Find elements by role in the markup, not by matching old text.
- **Colours differ per title.** Match an element's role rather than a hex value, or the pattern works on AR and fails on SubPrime.

## Templates
- **A check only sees what it looks for.** An early check passed with a hard-coded banner and sample copy still in the templates, because it only scanned some paths. `verify_templates.py` now checks every `src` and every sample string.
- **Empty fields render as nothing.** Mustache gives no error, so a missing unsubscribe link is silent. Validate before rendering.
- **Engines escape by default.** See `template-fields.md`.
- **Test against a real engine.** That is how the escaping problem was found.

## Email
- **Gmail and desktop Outlook won't load web fonts.** Anything that must look exact, such as a masthead, has to be an image with alt text.
- **Outlook ignores media queries.** It keeps the desktop creative, which is the right fallback.
- **Transparent PNGs show what's behind them.** The AR Canada masthead vanished on red because its art was transparent.

## Publishing
- **`robots.txt` only works at the root of a domain.** One placed in a GitHub Pages project folder is ignored.
- **`noindex` needs crawling to work.** Blocking a page in `robots.txt` also stops crawlers seeing its `noindex`.
- **Windows path limits are real.** Long paths produced false 404s on a local server and failed git operations. Keep this kit in a short path.
