# Design rules

Set by Eric Bearly while reviewing these newsletters. Treat them as settled unless
he changes them.

## Colour
- **Orange is an accent, never a background.** On Auto Remarketing, `#f57c29` is for kickers, thin rules and small call-to-action elements. No orange panels or bands of any size.
- **All chrome stays in one colour family.** Masthead, section chips, Editor's Picks, buttons, promo and footer are all the same family per title.
- **Brands stay separate.** Orange belongs to Auto Remarketing. SubPrime is blue `#005496` and grey `#808285`, with no orange. AR Canada is red, BHPH Report green and Auto Fin Journal purple, each sampled from its own live newsletter.

## Mastheads
- **AR Today (AM and PM):** one image, the full Auto Remarketing wordmark in white with "Today" or "Today pm" in orange right beside it, on the same baseline. CMG asked for the full title rather than the AR initials, bigger and bolder, with no gap across the page (November 2026). "Today" is set in Oswald Bold at 85% of the wordmark's capital height and the image fills the 602px content width, so it scales down on phones.
- **The masthead is an image, not text,** so it looks the same in clients that won't load web fonts. Regenerate it with `python tools/run_all.py --with-art` (it is built from the official `AR500.png` wordmark in `tools/arlogo/`).
- **SubPrime:** "Auto Finance News" sits under the logo.
- **Hosted art:** `logos/AR-Today-masthead.png` and `logos/AR-Today-PM-masthead.png` must be hosted, and their `src` values updated, before a real send.

## Stories
- **No date or byline on the lead story.** This applies to the short editions.
- **AR Today AM and SubPrime:** thumbnails above Editor's Picks; no photography below it. Sponsor logos stay throughout.
- **Short editions:** every story runs a full-width image like the lead, with the art larger than in AR Today.
- **Mobile stacks story art above the headline at full width.** A small thumbnail beside the text on a phone was rejected.
- **Editor's Picks:** three items, each with image, headline and blurb.

## Short editions
- PM carries 2 stories in the sample and can take up to 4.
- PM has an ad between every story and section, because it has few stories.
- On BHPH Report and Auto Fin Journal, an ad sits between Editor's Picks and the podcast section.
- Standing sections are named "Editor's Picks" and "Latest Podcasts".

## Footers
- The "Share on LinkedIn / Post on X / Sign up free" row was removed. Don't bring it back.

## Ads
- Every position is fixed for the length of a booking from 2027. Nothing rotates.
- Banners are horizontal only. A 300 x 250 option was built and removed; don't reintroduce it.
- Image banners carry no "Advertisement" or "Sponsored" header.
- Banners are full bleed with the same size in every position.

## Content and copy
- **Never invent content.** Every blurb, description, price, deadline or contract term must trace to a source. If it isn't in the source, leave it out and say so.
- Sample stories are real articles, read before the blurb was written.
- Commercial terms count too. An invented "Terms" block on a rate sheet was caught and removed.

## Review habits
- Send a fresh image of the result with every design change, at desktop and mobile width.
- Show the whole email first, then close-ups. Desktop and mobile go on separate pages.
- Use "desktop" and "mobile" in wording, not "phone".
- Look at the rendered result rather than trusting measurements.
