# Ad specifications

From the 2027 rate sheet. Pricing isn't in this package.

| Unit | Renders at | Supply | Copy and file |
|---|---|---|---|
| Banner, any position | 650 x 80 desktop, 375 x 62 mobile | 1300 x 160 and 750 x 124 (2x). An existing 728 x 90 is accepted and renders 650 x 80. | JPG, PNG or GIF. 100 KB desktop, 50 KB mobile. Brand the first frame of an animated GIF, because some clients show only that frame. |
| Text ad with logo or image | 170 x 170 desktop, 104 x 104 mobile | 340 x 340 (2x), square. Logo as transparent PNG, or photo as JPG. | Headline up to 50 characters, body up to 320, call to action up to 24, plus a destination URL. The whole block is one click. |

**Why these sizes.** They follow the IAB New Ad Portfolio's flexible ranges: the 8:1
leaderboard runs 600 x 75 to 1200 x 150, and the 6:1 smartphone banner runs 300 x 50
to 450 x 75. So each is a standard unit at native size. Without separate mobile art,
an 8:1 banner on a phone is about 46px tall. Clients that ignore media queries, such
as Outlook on Windows, keep the desktop file, which is the right fallback.

## Ad positions per edition

| Title | Positions |
|---|---|
| AR Today AM | 7 |
| AR Today PM | 6 |
| SubPrime News Update | 6 |
| AR Canada | 5 |
| BHPH Report News | 5 |
| Auto Fin Journal | 5 |
