---
name: cmg-newsletter
description: Build, change or check Cherokee Media Group e-newsletter templates (AR Today AM and PM, SubPrime News Update, AR Canada, BHPH Report News, Auto Fin Journal), including the HTML masters, merge-field templates, PDFs and a WordPress newsletter builder. Use for any work on these newsletters.
---

# CMG newsletters

## Read first
1. `docs/design-rules.md`: settled decisions. Don't undo them without being asked.
2. `docs/template-fields.md`: every merge field, and the escaping setting.
3. `docs/lessons-learned.md`: mistakes already made once.
4. `docs/wordpress-builder-notes.md` and `docs/ad-specs.md`: when working on the builder or ads.

## Where things live
- Masters: `newsletters/versions/` and `newsletters/subprime/versions/`
- Builder templates: `newsletters/templates/` (generated, don't edit by hand)
- Sample copy: `tools/content*.py`
- Images used by the samples: `tools/serve/`

## Which file to change
- **AR Today AM or SubPrime design:** edit its master.
- **AR Today PM:** generated from the AM master. Change `tools/build_pm.py` or the AM master.
- **AR Canada, BHPH Report, Auto Fin Journal:** generated. Change `tools/build_edition.py`, or the AM master.
- **A change to the AM master affects all of those.** Rebuild and check them.

## After any change
Run `python tools/run_all.py`. It stops on the first failure. Then:
1. Open a capture from `newsletters/samples/` at desktop and mobile width and look at it, including that Oswald loaded.
2. Show the person a fresh image of the result.

## Don't
- Invent copy, prices, terms, deadlines or descriptions.
- Put orange behind anything, or add images below Editor's Picks on AR Today AM or SubPrime.
- Send real email, or add a path that makes a send easier to reach, unless the person asks.
- Report something as working until you've seen it working.
