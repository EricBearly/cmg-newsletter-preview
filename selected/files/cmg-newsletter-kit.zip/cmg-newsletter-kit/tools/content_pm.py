"""Real content for the AR Today PM sample.

Every story here was pulled from autoremarketing.com on 21 Oct 2026 and the
articles were read before these blurbs were written. The three lead items all
carry that afternoon's timestamps (4:15, 3:02 and 12:01 PM), which is what a
PM edition actually rounds up. Nothing is invented; the single quotation is
reproduced as the article carries it.

EARLIER pulls that morning's AR Today, which is the point of an "in case you
missed it" rail. WORTH pulls AR's evergreen and commentary franchises.
"""

DATE = "Wednesday, Oct. 21, 2026"
EDITION = "Afternoon edition"
TAGLINE = "The News Media of the Pre-Owned Industry"

LEAD = {
    "cat": "Wholesale",
    "url": "https://www.autoremarketing.com/ar/wholesale/coparts-acquisition-of-acv-could-help-make-a-splash-in-commercial-consignment-too/",
    "img": "img/pm-copart-acv.jpg",
    "alt": "ACV's booth at the NADA Show",
    "head": "Copart&rsquo;s acquisition of ACV could help &lsquo;make a splash&rsquo; in commercial consignment, too",
    "deck": "The $1.9 billion all-cash deal closed last week, opening a route further into whole-car remarketing",
    "byline": "Joe Overby, Senior Editor &middot; 4:15 p.m.",
    "body": "Copart&rsquo;s $1.9 billion all-cash acquisition of ACV Auctions, which closed last week, is a chance to "
            "push further into whole-car remarketing, particularly among franchise dealers. Chief executive Jay Adair "
            "said shortly after the deal was announced, &ldquo;I think this opens up the world and our ability to do a "
            "lot more vehicles in that space.&rdquo; One analyst sees the commercial consignment market as a second "
            "place the combination could make a mark.",
}

BRIEFS = [
    {"cat": "Retail",
     "url": "https://www.autoremarketing.com/ar/retail/nada-elects-first-female-chair-since-2008-will-be-second-woman-overall-in-role/",
     "img": "img/pm-nada-chair.jpg",
     "head": "NADA elects first female chair since 2008, will be second woman overall in role",
     "byline": "3:02 p.m.",
     "body": "Sandy Fitzgerald Angello, a dealer operator at Pohanka Automotive Group in Maryland, was elected by the "
             "board to become chair of the National Automobile Dealers Association. She will be the second woman to "
             "hold the role and the first in nearly two decades."},
    {"cat": "Retail",
     "url": "https://www.autoremarketing.com/ar/retail/dealership-buy-sell-moves-from-md-to-calif-to-wisc/",
     "img": "img/pm-buysell.jpg",
     "head": "Dealership buy-sell moves from Md. to Calif. to Wisc.",
     "byline": "12:01 p.m.",
     "body": "Asbury Automotive Group has sold Kia of Owings Mills in Maryland, along with the related real estate, to "
             "Stivers Automotive Group, in a deal announced by adviser The Presidio Group. Asbury said it is managing "
             "its portfolio to concentrate on the core business and its main expansion opportunities; for Stivers the "
             "purchase is a first Kia store and a Mid-Atlantic foothold."},
]

# this morning's AR Today, for the in-case-you-missed-it rail
EARLIER = [
    ("Wholesale", "https://www.autoremarketing.com/ar/wholesale/wholesale-used-car-prices-drop-more-than-3-in-september/",
     "Wholesale used-car prices drop more than 3% in September"),
    ("Retail", "https://www.autoremarketing.com/ar/retail/dealers-asking-for-2-5-less-on-used-vehicles-than-they-were-a-month-ago/",
     "Dealers asking for 2.5% less on used vehicles than they were a month ago"),
    ("Auctions", "https://www.autoremarketing.com/ar/wholesale/naaa-names-next-leadership-rotation-hall-of-fame-inductee-industry-pioneer-more/",
     "NAAA names next leadership rotation, Hall of Fame inductee, Industry Pioneer &amp; more"),
    ("Technology", "https://www.autoremarketing.com/ar/technology/itochu-invests-in-moter-again-to-leverage-connected-car-technology/",
     "ITOCHU invests in MOTER again to leverage connected-car technology"),
]

# evergreen and commentary worth resurfacing
WORTH = [
    {"cat": "Commentary",
     "url": "https://www.autoremarketing.com/ar/analysis/commentary-dealers-dont-have-an-inventory-problem-they-have-a-decision-problem/",
"img": "img/pm-worth0.jpg",
     "head": "COMMENTARY: Dealers don&rsquo;t have an inventory problem; they have a decision problem",
     "body": "Why recognizing risk in a vehicle early beats reacting to it late."},
    {"cat": "Analysis",
     "url": "https://www.autoremarketing.com/ar/analysis/meet-the-40-under-40-industry-honorees-for-2026/",
"img": "img/pm-worth1.jpg",
     "head": "Meet the &lsquo;40 Under 40: Industry&rsquo; honorees for 2026",
     "body": "The latest installment of Auto Remarketing&rsquo;s 40 Under 40 franchise."},
    {"cat": "Commentary",
     "url": "https://www.autoremarketing.com/ar/wholesale/commentary-the-same-analytics-divide-reshaping-sports-is-now-reshaping-vehicle-acquisition/",
"img": "img/pm-worth2.jpg",
     "head": "COMMENTARY: The same analytics divide reshaping sports is now reshaping remarketing",
     "body": "What the front-office analytics shift tells us about wholesale decision-making."},
]


# The four most recent Auto Remarketing Podcast episodes, from the podcast
# feed on 21 Oct 2026. Two are sponsored episodes and carry that label in the
# feed, so they carry it here too.
PODCASTS = [
    ("Oct. 21", "https://www.autoremarketing.com/soundcloud_feed/used-car-week-hall-of-fame-grace-huang-of-cox-automotive/",
     "Used Car Week Hall of Fame: Grace Huang of Cox Automotive"),
    ("Oct. 20", "https://www.autoremarketing.com/soundcloud_feed/ben-sporn-of-vip-automotive-group-takes-diy-approach-to-ai/",
     "Ben Sporn of VIP Automotive Group Takes DIY Approach to AI"),
    ("Oct. 20", "https://www.autoremarketing.com/soundcloud_feed/sponsored-podcast-securing-the-vehicle-handoff-with-secure-vehicle-transfer/",
     "SPONSORED PODCAST: Securing the Vehicle Handoff with Secure Vehicle Transfer"),
    ("Oct. 13", "https://www.autoremarketing.com/soundcloud_feed/sponsored-episode-high-quality-used-inventory-via-the-service-drive-with-autohubs-dan-gaughan/",
     "SPONSORED EPISODE: High-quality used inventory via the service drive with AutoHub&rsquo;s Dan Gaughan"),
]
