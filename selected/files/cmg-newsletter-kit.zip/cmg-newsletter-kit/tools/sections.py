"""Shared section builders for the short newsletters.

picks_panel clones Editor's Picks from the AR Today source and repopulates it,
so "Worth another look" is the same card panel rather than a text list. Taking
the markup from the live file means each title's colours, radii and mobile
rules come along without being restated here.

bigger_thumbs widens the brief thumbnail. AR Today runs 170px against eight
stories; the short titles carry two to four, so the art can take more room.
"""
import re

CARD = re.compile(r'<div style="display:inline-block;width:100%;max-width:200px;[^"]*"[^>]*>.*?</div>', re.S)


def _card_template(picks_block):
    m = CARD.search(picks_block)
    assert m, "picks card not found"
    return m.group(0)


def picks_panel(picks_block, items, title, label, src_items):
    """items: dicts with cat/url/img/head/body.

    Every card is cloned from the FIRST source card and has that card's values
    swapped out. Pairing card N with src_items[N] looked tidier but silently
    left later cards unreplaced, because the markup being edited always came
    from card one - an Editor's Pick leaked into Worth Another Look.
    """
    card = _card_template(picks_block)
    src = src_items[0]
    built = []
    for it in items:
        c = card
        for key in ("img", "url", "head", "body", "cat"):
            assert src.get(key) and src[key] in c, f"card lacks {key}"
            c = c.replace(src[key], it[key], 1)
        built.append(c)

    out = picks_block
    out = re.sub(r'(>)Editor&rsquo;s Picks(<)', lambda m: m.group(1) + title + m.group(2), out)
    cards = list(CARD.finditer(out))
    out = out[:cards[0].start()] + (chr(10) + "      ").join(built) + out[cards[-1].end():]
    out = out.replace("5. EDITOR'S PICKS", label, 1)
    return out


def bigger_thumbs(html, px=230):
    """Widen the brief thumbnail and its cell."""
    html = html.replace('<td width="170" valign="top" class="thumb-cell" style="width:170px;',
                        f'<td width="{px}" valign="top" class="thumb-cell" style="width:{px}px;')
    html = html.replace('class="thumb" style="width:170px;', f'class="thumb" style="width:{px}px;')
    html = re.sub(r'(<img[^>]*class="thumb"[^>]*?)width="170"', r'\g<1>width="%d"' % px, html)
    return html


# The lead body is not in a span - it sits straight in a <td class="mp"> whose
# style carries the body type size, and the text starts on the next line. The
# earlier span-based match silently found nothing, so every sister edition ran
# AR Today's lead copy under its own headline. Match the row, keep the first,
# drop the rest.
BODY_ROW = re.compile(
    r'\s*<tr>\s*<td class="mp" style="[^"]*font-size:15px;line-height:26px;[^"]*">\s*'
    r'(?P<text>.*?)\s*</td>\s*</tr>', re.S)


def set_lead_body(lead_html, body):
    rows = list(BODY_ROW.finditer(lead_html))
    assert rows, "lead body row not found - markup changed"
    out = lead_html[:rows[0].start("text")] + body + lead_html[rows[0].end("text"):]
    # recompute offsets for the rows after the first, dropping them
    for m in list(BODY_ROW.finditer(out))[1:][::-1]:
        out = out[:m.start()] + out[m.end():]
    return out, len(rows)


DECK_ROW = re.compile(r'\s*<tr>\s*<td[^>]*>\s*<span class="lead-deck".*?</tr>', re.S)
BYLINE_ROW = re.compile(r'\s*<tr>\s*<td class="mp" style="[^"]*font-size:11px;font-weight:700;'
                        r'letter-spacing:0\.6px;[^"]*">.*?</tr>', re.S)
HEADLINE = re.compile(r'class="lead-hl" style="([^"]*)"')


def brief_from_lead(lead_block, item, src_lead, set_body, n):
    """Build a brief with a FULL-WIDTH image, like the lead.

    The side-thumbnail layout is replaced by the lead's own markup minus the
    deck and byline, so the art runs the full column. The headline drops to
    the brief size so the lead still reads as the lead.
    """
    t = lead_block
    for key in ("img", "head", "cat", "url"):
        assert src_lead[key] in t, f"lead lacks {key}"
        # url and img each appear more than once in the lead - the headline
        # link, the image link and Read more all carry the url. Replacing only
        # the first left every cloned brief pointing its picture and its Read
        # more at the AM lead story, which shipped in four editions.
        count = 1 if key in ("head", "cat") else -1
        t = t.replace(src_lead[key], item[key]) if count == -1 \
            else t.replace(src_lead[key], item[key], 1)
    t, _ = set_body(t, item["body"])
    t = DECK_ROW.sub("", t, count=1)
    t = BYLINE_ROW.sub("", t, count=1)
    t = HEADLINE.sub(lambda m: 'class="brief-hl" style="%s"' % m.group(1)
                     .replace("font-size:34px", "font-size:25px")
                     .replace("line-height:42px", "line-height:33px"), t)
    t = t.replace("3. LEAD STORY", f"STORY {n} - full-width art", 1)
    return t
