"""Re-measure, re-capture and re-copy the six chosen editions after a markup edit.

measure.py only covers the design variants; the five sister editions were built
later and are not in its list. This does the same job for exactly the six that
ship: measure at both capture widths from the DOM, shoot at those heights, and
refresh the serve/ and preview/ copies so the local test rig and the published
live preview are the same files the PDFs were shot from.

Run make_chosen_pdfs.py afterwards - it reads the captures this writes.
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from paths import BASE, CHROME, PORT
import pathlib, re, json, shutil, subprocess
from PIL import Image

SCR = pathlib.Path(__file__).parent
SERVE = SCR / "serve"
PREVIEW = SCR / "preview"

SP = BASE / "subprime"

PAD = 12

# id -> (source file, samples root)
SIX = {
    "theme-blue-darkflag": (BASE / "versions" / "theme-blue-darkflag.html", BASE),
    "ar-today-pm":         (BASE / "versions" / "ar-today-pm.html", BASE),
    "ar-canada":           (BASE / "versions" / "ar-canada.html", BASE),
    "bhph-report":         (BASE / "versions" / "bhph-report.html", BASE),
    "auto-fin-journal":    (BASE / "versions" / "auto-fin-journal.html", BASE),
    "sp-blue-darkflag":    (SP / "versions" / "sp-blue-darkflag.html", SP),
}

def localise(html):
    """Point every remote image at the copy already sitting in serve/img.

    The master keeps the real hosted URLs - that is what an ESP send
    needs - so the rig's copies are rewritten rather than the deliverable. The
    stems follow bundle_preview.py's rule, and a miss is an error rather than a
    silent broken image.
    """
    out, miss = html, []
    for u in sorted(set(re.findall(r'src="(https://[^"]+)"', html))):
        stem = re.sub(r"[^A-Za-z0-9._-]", "_", u.rsplit("/", 1)[-1].split("?")[0])
        if "zone_static" in u:
            stem = "leaderboard-" + u.split("zone_static/")[1].split("/")[0] + ".png"
        if "icons8" in u:
            stem = "icon-" + u.rstrip("/").rsplit("/", 1)[-1]
        rel = next((f"{d}/{stem}" for d in ("img", "logos", "splogos")
                    if (SERVE / d / stem).exists()), None)
        if rel is None:
            miss.append((u, stem))
            continue
        out = out.replace(f'src="{u}"', f'src="{rel}"')
    return out, miss


for vid, (src, _root) in SIX.items():
    html, miss = localise(src.read_text(encoding="utf-8"))
    assert not miss, f"{vid}: no local copy for {miss}"
    for dest in (SERVE, PREVIEW):
        (dest / f"{vid}.html").write_text(html, encoding="utf-8")
print(f"synced {len(SIX)} files into serve/ and preview/")

page = """<!doctype html><meta charset=utf-8>
<style>html,body{margin:0}iframe{border:0;display:block;height:400px}</style>
<pre id=out></pre><div id=hold></div>
<script>
const V = %s;
const hold = document.getElementById('hold');
function frame(id, w){
  const f = document.createElement('iframe');
  f.src = id + '.html'; f.style.width = w + 'px';
  hold.appendChild(f);
  return new Promise(r => f.addEventListener('load', () => r(f)));
}
async function settle(f){
  const d = f.contentDocument;
  await Promise.all([...d.images].map(i => i.complete ? null : new Promise(r => {
    i.addEventListener('load', r); i.addEventListener('error', r);
  })));
  await new Promise(r => setTimeout(r, 150));
  return d;
}
(async () => {
  const res = {};
  for (const id of V){
    const fd = await frame(id, 730); const dd = await settle(fd);
    const dh = dd.documentElement.scrollHeight;
    const broken = [...dd.images].filter(i => !i.naturalWidth).map(i => i.getAttribute('src'));
    const share = /Sign up free/.test(dd.body.textContent);
    fd.remove();
    const fp = await frame(id, 375); const pd = await settle(fp);
    const mh = pd.documentElement.scrollHeight;
    fp.remove();
    res[id] = {d: dh, m: mh, broken: broken, share: share};
  }
  document.getElementById('out').textContent = 'RESULT' + JSON.stringify(res);
})();
</script>""" % json.dumps(list(SIX))

(SERVE / "measuresix.html").write_text(page, encoding="utf-8")
dom = subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars",
                      "--virtual-time-budget=90000", "--window-size=900,800", "--dump-dom",
                      f"http://127.0.0.1:{PORT}/measuresix.html"],
                     capture_output=True, text=True, encoding="utf-8", errors="replace").stdout
m = re.search(r"RESULT(\{.*?\})</pre>", dom, re.S)
assert m, "measurement did not complete"
R = json.loads(m.group(1))

for vid, v in R.items():
    assert not v["broken"], f"{vid}: broken images {v['broken']}"
    assert not v["share"], f"{vid}: share row still present"


def shoot(page_, width, height, dest):
    (SERVE / "shot.html").write_text(
        '<!doctype html><meta charset=utf-8>'
        f'<style>html,body{{margin:0;padding:0;background:#fff}}'
        f'iframe{{width:{width}px;height:{height}px;border:0;display:block}}</style>'
        f'<iframe src="{page_}"></iframe>', encoding="utf-8")
    subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars",
                    "--force-device-scale-factor=2", "--virtual-time-budget=25000",
                    f"--window-size={width},{height}", f"--screenshot={dest}",
                    f"http://127.0.0.1:{PORT}/shot.html"], capture_output=True)


for vid, (_src, root) in SIX.items():
    samples = root / "samples"
    (samples / "print").mkdir(parents=True, exist_ok=True)
    dh, mh = R[vid]["d"], R[vid]["m"]
    shoot(f"{vid}.html", 730, dh + PAD, samples / "print" / f"{vid}.png")
    shoot(f"{vid}.html", 375, mh + PAD, samples / f"{vid}-phone.png")
    im = Image.open(samples / "print" / f"{vid}.png")
    im.resize((im.width // 2, im.height // 2), Image.LANCZOS).save(
        samples / f"{vid}-desktop.png", optimize=True)
    print(f"{vid:22s} desktop {dh:5d} -> {im.size}  mobile {mh:5d} -> "
          f"{Image.open(samples / f'{vid}-phone.png').size}")
