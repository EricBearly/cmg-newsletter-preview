"""Build AR Today PM from the chosen AR Today design.

The real PM carries two stories against roughly eight ad placements, which is
why it reads as an ad sheet with news attached. The fix is not fewer ads, it
is more editorial to hang them on, so this adds two standing sections below
the news:

  EARLIER TODAY       the morning edition's headlines - in case you missed it
  WORTH ANOTHER LOOK  evergreen and commentary worth resurfacing
  LATEST PODCASTS     the four most recent Auto Remarketing Podcast episodes

Layout: the sample runs TWO new stories, then the three sections, with an ad
between every one of them. Six units, none adjacent:

  LEADER | lead story | AD2 | story 2 | AD3 | EARLIER TODAY | AD4
         | WORTH ANOTHER LOOK | AD5 | LATEST PODCASTS | AD6 | promo

STORY_COUNT sets how many of the day's own stories run. Two is the sample;
the three standing sections carry enough weight to separate every ad unit on
a thin news afternoon. Raise it to 3 or 4 on a heavier day and the extra
stories push in above EARLIER TODAY, keeping an ad between each.

Everything is cloned from the AM file, so the chrome, colours, type and the
banner/text-ad formats are identical by construction rather than by copying
values that can drift.
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from paths import BASE
import pathlib, re, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import content as C
import content_pm as P
import sections as SEC


SRC = BASE / "versions" / "theme-blue-darkflag.html"
OUT = BASE / "versions" / "ar-today-pm.html"
ORANGE, INK = "#f57c29", "#0f1419"
STORY_COUNT = 2          # the day's own stories: 2 in the sample, up to 4

s = SRC.read_text(encoding="utf-8")


def block(marker, src=None):
    t = src if src is not None else s
    i = t.index(marker)
    a = t.rindex("<!--", 0, i)
    b = t.index("\n</table>", i) + len("\n</table>\n")
    return t[a:b]


LEAD_B = block("3. LEAD STORY")
BRIEF_B = block("<!-- STORY 2 ")
AD_B = block("     AD 2 - TEXT AD WITH LOGO")
BANNER_B = block("IN-CONTENT BANNER")
HEADS_B = block("6. MORE HEADLINES")


def swap(t, pairs, once=()):
    """Replace every occurrence unless the field is listed in `once`.

    The lead's url appears three times - headline, picture, Read more - so
    replacing only the first left the picture and the Read more link aimed at
    the AM lead story.
    """
    for i, (a, b) in enumerate(pairs):
        assert a in t, f"not found: {a[:60]}"
        t = t.replace(a, b, 1) if i in once else t.replace(a, b)
    return t


# ---- lead story
am_lead = C.LEAD
lead = swap(LEAD_B, [
    (am_lead["img"], P.LEAD["img"]),
    (am_lead["head"], P.LEAD["head"]),
    (am_lead["deck"], P.LEAD["deck"]),
    (am_lead["byline"], P.LEAD["byline"]),
    (am_lead["cat"], P.LEAD["cat"]),
    (am_lead["url"], P.LEAD["url"]),
], once=(1, 2, 3, 4))   # head, deck, byline and chip appear once; img and url repeat
# the body is split across paragraphs in the source; replace the first, drop the rest
lead, _n = SEC.set_lead_body(lead, P.LEAD["body"])
lead = SEC.BYLINE_ROW.sub('', lead, count=1)   # no byline or time on the lead

# ---- two briefs with art
am_brief = C.BRIEFS[0]
briefs = []
for k, b in enumerate(P.BRIEFS[:STORY_COUNT - 1], start=2):
    briefs.append(SEC.brief_from_lead(LEAD_B, b, C.LEAD, SEC.set_lead_body, k))

# ---- ads: text, banner, text, text, text
def text_ad(n, ad):
    cur = {a["n"]: a for a in C.ADS}[2]
    t = AD_B.replace("AD 2 - TEXT AD WITH LOGO", f"AD {n} - TEXT AD WITH LOGO")
    t = t.replace("{{AD2_URL}}", f"{{{{AD{n}_URL}}}}")
    return swap(t, [(cur["logo"], ad["logo"]),
                    (f'alt="{cur["name"]} logo"', f'alt="{ad["name"]} logo"'),
                    (cur["head"], ad["head"]), (cur["body"], ad["body"]),
                    (f'{cur["cta"]} &#8250;', f'{ad["cta"]} &#8250;')])


ADS = {a["n"]: a for a in C.ADS}
ad2 = text_ad(2, ADS[2])
ad3 = BANNER_B.replace("{{AD4_URL}}", "{{AD3_URL}}")
ad4 = text_ad(4, ADS[3])
ad5 = text_ad(5, ADS[5])
ad6 = text_ad(6, ADS[7])


# ---- a standing section, built on the More Headlines pattern
def section(title, items, label, note=None):
    rows = []
    for i, (cat, url, head, *rest) in enumerate(items):
        sub = f'<span style="font-family:\'Open Sans\',\'Segoe UI\',Helvetica,Arial,sans-serif;font-size:13px;color:#5a6672;line-height:20px;display:block;padding-top:4px;">{rest[0]}</span>' if rest else ""
        rows.append(
            (f'        <tr><td style="padding:12px 0 0 0;"><div style="height:1px;background-color:#dde2e7;font-size:0;line-height:0;">&nbsp;</div></td></tr>\n' if i else "") +
            f'''        <tr>
          <td style="padding:{'12px' if i else '0'} 0 0 0;">
            <span style="font-family:'Oswald','Arial Narrow',Arial,sans-serif;font-size:10px;font-weight:600;letter-spacing:1.4px;text-transform:uppercase;color:{ORANGE};display:block;padding-bottom:4px;">{cat}</span>
            <a href="{url}" style="font-family:'Noto Serif',Georgia,'Times New Roman',serif;font-size:16px;font-weight:700;color:{INK};line-height:24px;text-decoration:none;">{head}</a>{sub}
          </td>
        </tr>''')
    sub = f'''  <tr>
    <td class="mp" style="padding:12px 24px 0 24px;font-family:'Open Sans','Segoe UI',Helvetica,Arial,sans-serif;font-size:12px;color:#6b7785;">{note}</td>
  </tr>''' if note else ""
    return f'''<!-- =============================================
     {label}
     ============================================= -->
<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color:#f4f6f8;border-top:1px solid #d4d9de;">
  <tr>
    <td class="mp" style="padding:24px 24px 0 24px;">
      <span style="font-family:'Oswald','Arial Narrow',Arial,sans-serif;font-size:17px;font-weight:700;letter-spacing:2.5px;text-transform:uppercase;color:{INK};border-bottom:3px solid {ORANGE};padding-bottom:6px;">{title}</span>
    </td>
  </tr>
{sub}
  <tr>
    <td class="mp" style="padding:18px 24px 24px 24px;">
      <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
{chr(10).join(rows)}
      </table>
    </td>
  </tr>
</table>
'''


earlier = section("Earlier today", P.EARLIER, "A. EARLIER TODAY",
                  "From this morning&rsquo;s edition, in case you missed it.")
worth = SEC.picks_panel(block("5. EDITOR'S PICKS"), P.WORTH,
                        "Editor&rsquo;s Picks", "B. EDITOR'S PICKS", C.PICKS)
pods = section("Latest podcasts", P.PODCASTS, "C. LATEST PODCASTS",
               "New episodes of the Auto Remarketing Podcast.")

# one ad between every story and every section
units = [ad2, ad3, ad4, ad5, ad6]
blocks = [lead] + briefs + [earlier, worth, pods]
BODY = ""
for n, blk in enumerate(blocks):
    BODY += blk
    if n < len(units):
        BODY += units[n]

# ---- splice: keep the chrome, replace the middle.
# Index off the MARKER then walk back to its comment opener; the opener line
# itself is identical in every block, so searching for it finds the first one
# in the file and swallows the masthead.
i = s.rindex("<!--", 0, s.index("3. LEAD STORY"))
j = s.rindex("<!--", 0, s.index("7. USED CAR WEEK"))
out = s[:i] + BODY + s[j:]

# ---- masthead and date strip
# the masthead is one image (wordmark + Today), so PM swaps the file
_am_flag = 'src="logos/AR-Today-masthead.png" width="601" height="102" alt="Auto Remarketing Today" class="flag-lockup" style="width:100%;max-width:601px;'
assert _am_flag in out, "AM masthead image not found"
out = out.replace(_am_flag, 'src="logos/AR-Today-PM-masthead.png" width="601" height="91" alt="Auto Remarketing Today PM" class="flag-lockup" style="width:100%;max-width:601px;', 1)
assert "logos/AR-Today-masthead.png must" in out, "masthead hosting note not found"
out = out.replace("logos/AR-Today-masthead.png must", "logos/AR-Today-PM-masthead.png must", 1)
assert "logos/AR-Today-masthead.png" not in out, "PM still references the AM masthead image"
out = out.replace(C.DATE, P.DATE)
out = re.sub(r'<td valign="middle" class="m-hide"[^>]*>[^<]*</td>',
             '<td valign="middle" class="m-hide"></td>', out, count=1)
# the footer wordmark is two spans, so the combined string never matches;
# the orange half is the one that carries the edition name
out = out.replace(">&nbsp;Today</span>", ">&nbsp;Today PM</span>", 1)
out = out.replace("from Auto Remarketing.", "from Auto Remarketing Today PM.")

OUT.write_text(out, encoding="utf-8")

marks = [("LEADER", "AD 1 - TOP LEADERBOARD"), ("LEAD", "3. LEAD STORY"),
         ("AD2", "     AD 2 - TEXT"), ("S2", "     STORY 2 - full-width art"), ("AD3", "IN-CONTENT BANNER"),
         ("AD4", "     AD 4 - TEXT"), ("EARLIER", "A. EARLIER TODAY"),
         ("AD5", "     AD 5 - TEXT"), ("PICKS", "B. EDITOR'S PICKS"),
         ("PODS", "C. LATEST PODCASTS"),
         ("AD6", "     AD 6 - TEXT"), ("UCW", "7. USED CAR WEEK")]
seq = [l for _, l in sorted((out.index(m), l) for l, m in marks if m in out)]
isad = lambda x: x.startswith("AD") or x == "LEADER"
stacked = [(a, b) for a, b in zip(seq, seq[1:]) if isad(a) and isad(b)]
print("order:", " ".join(seq))
print("units:", sum(1 for x in seq if isad(x)), "| stacked:", stacked or "none")
print("written:", OUT.name, len(out) // 1024, "kB")
