"""Build a sister title from the chosen AR Today design.

One builder, brand palette passed in, so AR Canada and BHPH Report News come
out structurally identical to AR Today and to each other - the only thing that
changes is colour, masthead and content.

PALETTE. Each title has one colour, so the chrome runs dark -> mid -> chip in
that colour and the accent is the bright brand tone, which is the same system
SubPrime already uses (bright blue on deep blue). Brand values were sampled
from the live newsletters: AR Canada red is rgb(237,28,36), BHPH green is
rgb(43,136,69).

MASTHEAD. Each title already has its own header artwork, so that is used
rather than a wordmark rebuilt from parts.

LAYOUT. Five ad units, an ad between every story and section:
  LEADER | stories... | WORTH ANOTHER LOOK | LATEST PODCASTS | promo
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from paths import BASE
import pathlib, re, sys
from PIL import Image
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import content as C
import sections as SEC


SRC = BASE / "versions" / "theme-blue-darkflag.html"

# AR Today's palette, the keys being replaced
AR = dict(dark="#0d2b45", mid="#194568", chip="#336178", div="#2a4a66",
          accent="#f57c29", accent_soft="#f9a86b", panel="#fdf4ec",
          pick_body="#9fb9ce", flagrule="#f57c29")

EDITIONS = {
    "ar-canada": dict(
        mod="content_arc",
        pal=dict(dark="#8c1016", mid="#b5141b", chip="#c4151c", div="#a3242a",
                 accent="#ed1c24", accent_soft="#ff9ba0", panel="#fdeced",
                 pick_body="#f3b9bc", flagrule="#ed1c24"),
        stories=2),
    "auto-fin-journal": dict(
        mod="content_afj",
        pal=dict(dark="#3d1943", mid="#55235c", chip="#6b2f74", div="#5d2a66",
                 accent="#8e4a98", accent_soft="#c79bcd", panel="#f6eef7",
                 pick_body="#cbb0d0", flagrule="#8e4a98"),
        stories=4),
    "bhph-report": dict(
        mod="content_bhph",
        pal=dict(dark="#1b5c2f", mid="#246b38", chip="#2b8845", div="#2f7a44",
                 accent="#2b8845", accent_soft="#86d49c", panel="#edf7f0",
                 pick_body="#b5dcc2", flagrule="#2b8845"),
        stories=4),
}


def build(key):
    spec = EDITIONS[key]
    P = __import__(spec["mod"])
    pal = spec["pal"]
    s = SRC.read_text(encoding="utf-8")

    def block(marker, t=None):
        t = s if t is None else t
        i = t.index(marker)
        a = t.rindex("<!--", 0, i)
        b = t.index("\n</table>", i) + len("\n</table>\n")
        return t[a:b]

    LEAD_B, BRIEF_B = block("3. LEAD STORY"), block("<!-- STORY 2 ")
    AD_B, BANNER_B = block("     AD 2 - TEXT AD WITH LOGO"), block("IN-CONTENT BANNER")

    def swap(t, pairs, once=()):
        """Replace every occurrence unless the field is named in `once`.

        The lead carries its url three times - headline, picture and Read
        more - so a single replacement left the picture and the Read more
        link pointing at the AM lead story in every sister edition.
        """
        for (a, b), key_name in pairs:
            assert a in t, f"{key}: not found {a[:50]}"
            t = t.replace(a, b, 1) if key_name in once else t.replace(a, b)
        return t

    lead = swap(LEAD_B,
                [((C.LEAD[k], P.LEAD[k]), k)
                 for k in ("img", "head", "deck", "byline", "cat", "url")],
                once=("head", "deck", "byline", "cat"))
    lead, _n = SEC.set_lead_body(lead, P.LEAD["body"])
    lead = SEC.BYLINE_ROW.sub('', lead, count=1)   # no byline or time on the lead

    briefs = []
    for n, b in enumerate(P.BRIEFS[:spec["stories"] - 1], start=2):
        briefs.append(SEC.brief_from_lead(LEAD_B, b, C.LEAD, SEC.set_lead_body, n))

    ADS = {a["n"]: a for a in C.ADS}

    def text_ad(n, ad):
        cur = ADS[2]
        t = AD_B.replace("AD 2 - TEXT AD WITH LOGO", f"AD {n} - TEXT AD WITH LOGO").replace("{{AD2_URL}}", f"{{{{AD{n}_URL}}}}")
        return swap(t, [((cur["logo"], ad["logo"]), "logo"),
                        ((f'alt="{cur["name"]} logo"', f'alt="{ad["name"]} logo"'), "name"),
                        ((cur["head"], ad["head"]), "head"),
                        ((cur["body"], ad["body"]), "body"),
                        ((f'{cur["cta"]} &#8250;', f'{ad["cta"]} &#8250;'), "cta")])

    units = [text_ad(2, ADS[2]), BANNER_B.replace("{{AD4_URL}}", "{{AD3_URL}}"),
             text_ad(4, ADS[5]), text_ad(5, ADS[7])]

    def section(title, items, label, note=None):
        rows = []
        for i, it in enumerate(items):
            cat, url, head, *rest = it
            sub = (f'<span style="font-family:\'Open Sans\',\'Segoe UI\',Helvetica,Arial,sans-serif;font-size:13px;'
                   f'color:#5a6672;line-height:20px;display:block;padding-top:4px;">{rest[0]}</span>') if rest else ""
            rows.append(
                (f'        <tr><td style="padding:12px 0 0 0;"><div style="height:1px;background-color:#dde2e7;font-size:0;line-height:0;">&nbsp;</div></td></tr>\n' if i else "") +
                f'''        <tr>
          <td style="padding:{'12px' if i else '0'} 0 0 0;">
            <span style="font-family:'Oswald','Arial Narrow',Arial,sans-serif;font-size:10px;font-weight:600;letter-spacing:1.4px;text-transform:uppercase;color:{pal['accent']};display:block;padding-bottom:4px;">{cat}</span>
            <a href="{url}" style="font-family:'Noto Serif',Georgia,'Times New Roman',serif;font-size:16px;font-weight:700;color:#0f1419;line-height:24px;text-decoration:none;">{head}</a>{sub}
          </td>
        </tr>''')
        n = (f'''  <tr>
    <td class="mp" style="padding:12px 24px 0 24px;font-family:'Open Sans','Segoe UI',Helvetica,Arial,sans-serif;font-size:12px;color:#6b7785;">{note}</td>
  </tr>''') if note else ""
        return f'''<!-- =============================================
     {label}
     ============================================= -->
<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color:#f4f6f8;border-top:1px solid #d4d9de;">
  <tr>
    <td class="mp" style="padding:24px 24px 0 24px;">
      <span style="font-family:'Oswald','Arial Narrow',Arial,sans-serif;font-size:17px;font-weight:700;letter-spacing:2.5px;text-transform:uppercase;color:#0f1419;border-bottom:3px solid {pal['accent']};padding-bottom:6px;">{title}</span>
    </td>
  </tr>
{n}
  <tr>
    <td class="mp" style="padding:18px 24px 24px 24px;">
      <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
{chr(10).join(rows)}
      </table>
    </td>
  </tr>
</table>
'''

    worth = SEC.picks_panel(block("5. EDITOR'S PICKS"), P.WORTH,
                            "Editor&rsquo;s Picks", "A. EDITOR'S PICKS", C.PICKS)
    pods = section("Latest podcasts", P.PODCASTS, "B. LATEST PODCASTS",
                   "New episodes of the Auto Remarketing Podcast.")

    blocks = [lead] + briefs + [worth, pods]
    # An ad always sits after the lead and after Editor's Picks; the rest fill
    # in after the briefs. With four in-body units and six blocks something has
    # to be adjacent, and two stories touching reads better than Picks running
    # straight into the podcasts.
    picks_at = len(briefs) + 1
    slots = [0, picks_at]
    for k in range(1, picks_at):
        if len(slots) < len(units) and k not in slots:
            slots.append(k)
    while len(slots) < len(units):
        slots.append(len(blocks) - 1)
    slots = sorted(set(slots))[:len(units)]
    BODY = ""
    u = 0
    for n, blk in enumerate(blocks):
        BODY += blk
        if n in slots and u < len(units):
            BODY += units[u]; u += 1

    i = s.rindex("<!--", 0, s.index("3. LEAD STORY"))
    k = s.rindex("<!--", 0, s.index("7. USED CAR WEEK"))
    out = s[:i] + BODY + s[k:]

    # ---- recolour the chrome, longest values first so no value is half-replaced
    for role in ("dark", "mid", "chip", "div", "accent_soft", "accent", "panel", "pick_body"):
        out = re.sub(AR[role], pal[role], out, flags=re.I)

    # On a single-colour brand the accent sits on a band of its own colour, so
    # inside the Used Car Week promo the soft tint is used instead. AR got away
    # with orange on navy; green on green vanished.
    pi = out.index("7. USED CAR WEEK")
    pj = out.index("8.", pi) if "8." in out[pi:pi+9000] else len(out)
    promo = out[pi:pj].replace(pal["accent"], pal["accent_soft"])
    # the soft tint is for TYPE on the band; the call-to-action keeps the solid
    # accent or it becomes a pale button carrying white text
    for attr in (f'background-color:{pal["accent_soft"]}', f'fillcolor="{pal["accent_soft"]}"',
                 f'strokecolor="{pal["accent_soft"]}"'):
        promo = promo.replace(attr, attr.replace(pal["accent_soft"], pal["accent"]))
    out = out[:pi] + promo + out[pj:]

    # ---- masthead: the title's own header artwork, full width on the flag
    # The AR flag has had three shapes: the old wordmark-left / Today-right
    # pair, the stacked AR mark with Today beside it, and now one linked image
    # (wordmark + Today). Sister titles replace the whole lockup with their own
    # header artwork whichever it is, so match the structure, not the AR art.
    flag_inner = re.search(
        r'<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">\s*'
        r'<tr>\s*<td valign="(?:middle|bottom)"[^>]*>.*?</td>\s*'
        r'<td valign="(?:middle|bottom)"[^>]*class="[^"]*flag-cell"[^>]*>.*?</td>\s*</tr>\s*</table>',
        out, re.S)
    if not flag_inner:
        # one-image flag: its cell padding is the lockup's, so put back the
        # padding the sister flags were built with
        out = out.replace('<td class="mp" style="padding:18px 24px 18px 24px;">\n      <a',
                          '<td class="mp" style="padding:10px 24px 14px 24px;">\n      <a', 1)
        flag_inner = re.search(r'<a href="[^"]*"[^>]*><img [^>]*class="flag-lockup"[^>]*></a>', out)
    assert flag_inner, f"{key}: flag lockup not matched"
    out = out[:flag_inner.start()] + f'''<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
        <tr>
          <td align="center" style="text-align:center;padding:0;font-size:0;line-height:0;">
            <a href="{P.SITE}" target="_blank">
              <img src="{P.HEADER_IMG}" width="650" alt="{P.BRAND}" class="fluid-img"
                   style="width:100%;max-width:650px;height:auto;display:block;">
            </a>
          </td>
        </tr>
      </table>''' + out[flag_inner.end():]

    # The masthead artwork is a finished header in the title's own colours and
    # several are transparent PNGs, so anything behind them shows through: on
    # the red band AR Canada's red "Canada" was red-on-red and the black
    # wordmark went muddy. Whiten EVERY band in the flag region - the first
    # table there is a 5px spacer, so replacing only the first missed the
    # masthead itself - and let the brand colour start at the date strip.
    fi = out.index("2. FLAG")
    fj = out.index("AD 1 - TOP LEADERBOARD")
    flag = out[fi:fj]
    flag = flag.replace(f'background-color:{pal["dark"]};', 'background-color:#ffffff;')
    flag = flag.replace('<td class="mp" style="padding:20px 24px 18px 24px;">',
                        '<td style="padding:0;font-size:0;line-height:0;">', 1)
    out = out[:fi] + flag + out[fj:]

    out = out.replace(C.DATE, P.DATE)
    # the strip carries the date only; the tagline is already in the masthead
    out = re.sub(r'<td valign="middle" class="m-hide"[^>]*>[^<]*</td>',
                 '<td valign="middle" class="m-hide"></td>', out, count=1)

    # if the masthead artwork sits on a light background, the utility bar above
    # it goes light too, so the dark chrome does not frame a white panel
    art = Image.open(pathlib.Path(__file__).parent / "serve" / P.HEADER_IMG).convert("RGB")
    corner = art.getpixel((2, 2))
    if sum(corner) > 600:
        ui = out.index("1. UTILITY BAR"); uj = out.index("2. FLAG")
        bar = out[ui:uj]
        bar = bar.replace(f'width="100%" style="background-color:{pal["dark"]};">',
                          'width="100%" style="background-color:#ffffff;">', 1)
        bar = bar.replace("color:#8d99a5;", "color:#6b7785;")
        bar = bar.replace('style="color:#c3cdd7;text-decoration:none;"', 'style="color:#6b7785;text-decoration:none;"')
        bar = bar.replace('style="color:#ffffff;text-decoration:underline;font-weight:700;"',
                          'style="color:#0f1419;text-decoration:underline;font-weight:700;"')
        bar = bar.replace('<span style="color:#3d4852;">', '<span style="color:#c3cdd7;">')
        out = out[:ui] + bar + out[uj:]
        print(f"   {key}: light masthead artwork -> light utility bar")
    out = out.replace(">Auto Remarketing</span>", f">{P.BRAND}</span>")
    out = out.replace(">&nbsp;Today</span>", ">&nbsp;</span>")
    out = out.replace("from Auto Remarketing.", f"from {P.BRAND}.")
    out = re.sub(r'<title>[^<]*</title>', f'<title>{P.BRAND}</title>', out)

    dest = BASE / "versions" / f"{key}.html"
    dest.write_text(out, encoding="utf-8")

    marks = [("LEADER", "AD 1 - TOP LEADERBOARD"), ("LEAD", "3. LEAD STORY"),
             ("AD2", "     AD 2 - TEXT"), ("AD3", "IN-CONTENT BANNER"),
             ("AD4", "     AD 4 - TEXT"), ("AD5", "     AD 5 - TEXT"),
             ("PICKS", "A. EDITOR'S PICKS"), ("PODS", "B. LATEST PODCASTS"),
             ("UCW", "7. USED CAR WEEK")] + [(f"S{n}", f"     STORY {n} - full-width art") for n in range(2, 6)]
    seq = [l for _, l in sorted((out.index(m), l) for l, m in marks if m in out)]
    isad = lambda x: x.startswith("AD") or x == "LEADER"
    stacked = [(a, b) for a, b in zip(seq, seq[1:]) if isad(a) and isad(b)]
    print(f"{key}: {' '.join(seq)}")
    print(f"   units {sum(1 for x in seq if isad(x))} | stacked {stacked or 'none'} | "
          f"AR navy left {len(re.findall('#0d2b45|#194568|#336178', out))} | {len(out)//1024} kB")


if __name__ == "__main__":
    for k in (sys.argv[1:] or ["ar-canada"]):
        build(k)
