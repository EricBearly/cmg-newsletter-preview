"""Turn the finished sample emails into builder templates.

The sample is the proof; the template is the thing a newsletter builder fills.
Same markup, same chrome, with every piece of editorial copy and every image
replaced by a merge field, and every ad wrapped in a section so the block
disappears when that position is unsold rather than leaving a hole.

Syntax is Mustache, because it is the one templating language that every
stack already reads - PHP, JS, Python, Ruby, and Handlebars and Liquid are
near enough to port in an afternoon. The files already used {{AD1_URL}}, so
this extends a convention rather than inventing one.

  {{field}}                  a value
  {{#thing}} ... {{/thing}}  renders once for a hash, once per item for a
                             list, not at all when absent, false or empty
  {{.}}                      the current item, where a list holds strings

Runs of stories sit between fixed ad positions, so each run is its own list:
drop in two stories or five and the ads stay where the design puts them.
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from paths import BASE
import pathlib, re, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import content as C, content_pm as P, content_sp as S


OUT = BASE / "templates"
OUT.mkdir(exist_ok=True)


def block_span(s, marker):
    """The whole comment-plus-table block that `marker` sits in."""
    i = s.index(marker)
    a = s.rindex("<!--", 0, i)
    b = s.index("\n</table>", i) + len("\n</table>\n")
    return a, b


def wrap(s, marker, name):
    a, b = block_span(s, marker)
    return s[:a] + "{{#%s}}\n" % name + s[a:b] + "{{/%s}}\n" % name + s[b:]


def sub1(s, old, new, what):
    assert s.count(old) >= 1, f"missing {what}: {old[:70]!r}"
    return s.replace(old, new, 1)


def suball(s, old, new, what):
    assert old in s, f"missing {what}: {old[:70]!r}"
    return s.replace(old, new)


# --------------------------------------------------------------- lead story
def tokenise_lead(s, _lead=None, prefix="LEAD"):
    """Tokenise the lead from its own markup, not from the content module.

    The modules have drifted from the files more than once - a later fix
    script swaps a picture or a link and nobody updates the module - and
    matching a stale literal either fails loudly or, worse, quietly rewrites
    the wrong element somewhere else in the document. Everything here is
    found by its role in the lead block.
    """
    a, b = block_span(s, "3. LEAD STORY")
    blk = s[a:b]

    def img(m):
        tag = re.sub(r'src="[^"]*"', 'src="{{%s_IMG}}"' % prefix, m.group(0), count=1)
        return re.sub(r'alt="[^"]*"', 'alt="{{%s_ALT}}"' % prefix, tag, count=1)

    blk, n = re.subn(r'<img[^>]*class="fluid-img"[^>]*>', img, blk, count=1)
    assert n == 1, "lead image not found"
    blk, n = re.subn(r'href="https?://[^"]*"', 'href="{{%s_URL}}"' % prefix, blk)
    assert n >= 1, "lead url not found"
    blk, n = re.subn(r'(<span class="lead-hl"[^>]*>)[^<]*(</span>)',
                     r'\g<1>{{%s_HEAD}}\g<2>' % prefix, blk, count=1)
    assert n == 1, "lead headline not found"
    blk, n = re.subn(r'(<td style="background-color:#[0-9a-fA-F]{3,6};padding:5px[^"]*">)[^<]*(</td>)',
                     r'\g<1>{{%s_CAT}}\g<2>' % prefix, blk, count=1)
    assert n == 1, "lead chip not found"
    blk = re.sub(r'(<span class="lead-deck"[^>]*>)[^<]*(</span>)',
                 r'\g<1>{{%s_DECK}}\g<2>' % prefix, blk, count=1)
    # the byline row is dropped on the short editions, so its absence is fine
    blk = re.sub(r'(<td class="mp" style="[^"]*font-size:11px;font-weight:700;'
                 r'letter-spacing:0\.6px;[^"]*">\s*)[^<]*?(\s*</td>)',
                 r'\g<1>{{%s_BYLINE}}\g<2>' % prefix, blk, count=1)
    return s[:a] + blk + s[b:]


BODY_ROW = re.compile(
    r'(\s*<tr>\s*<td class="mp" style="[^"]*font-size:15px;line-height:26px;[^"]*">\s*)'
    r'(?P<text>[^<]*?)(\s*</td>\s*</tr>)', re.S)


def loop_lead_body(s, prefix="LEAD"):
    """Collapse the lead's paragraphs into one repeating row.

    Scoped to the lead block: the same 15px/26px row style is used elsewhere,
    and a document-wide match would eat rows that are not the lead's body.
    """
    a, b = block_span(s, "3. LEAD STORY")
    head, blk, tail = s[:a], s[a:b], s[b:]
    return head + _loop_body(blk, prefix) + tail


def _loop_body(s, prefix):
    rows = list(BODY_ROW.finditer(s))
    assert rows, "lead body rows not found"
    first = rows[0]
    body = (first.group(1) + "{{.}}" + first.group(3))
    out = s[:first.start()] + "{{#%s_BODY}}" % prefix + body + "{{/%s_BODY}}" % prefix + s[first.end():]
    # the remaining paragraphs are the same field, so they go
    for m in list(BODY_ROW.finditer(out))[1:][::-1]:
        out = out[:m.start()] + out[m.end():]
    return out


# -------------------------------------------------------------- story runs
# Two shapes in the wild: the AM/SubPrime briefs carry a one-line
# `<!-- STORY n -->`, while the short editions' full-width briefs are cloned
# from the lead and keep its banner comment with the marker on its own line.
STORY = re.compile(
    r"(?:<!-- STORY \d+[^>]*-->|<!-- =+\n\s*STORY \d+[^\n]*\n\s*=+ -->)\n"
    r"(?:.*?)\n</table>\n", re.S)
THUMB_CELL = re.compile(
    r'\s*<td width="170" valign="top" class="thumb-cell".*?</td>\n', re.S)


def story_template(block):
    """One story block with its values swapped for fields.

    The thumbnail cell is its own section: a story filed without art renders
    as a full-width brief instead of leaving a 170px gap.
    """
    t = block
    t = re.sub(r'<a href="[^"]*"', '<a href="{{URL}}"', t)
    def _thumb(m):
        # src precedes class in these tags, so rewrite the tag as a whole
        tag = re.sub(r'src="[^"]*"', 'src="{{IMG}}"', m.group(0), count=1)
        return re.sub(r'alt="[^"]*"', 'alt="{{ALT}}"', tag, count=1)

    t = re.sub(r'<img[^>]*class="thumb"[^>]*>', _thumb, t)
    t = re.sub(r'<img[^>]*class="fluid-img"[^>]*>', _thumb, t)
    t = re.sub(r'(<td style="background-color:#[0-9a-fA-F]{3,6};padding:5px[^"]*">)[^<]*(</td>)',
               r'\g<1>{{CAT}}\g<2>', t)
    rows = list(BODY_ROW.finditer(t))
    if rows:
        t = t[:rows[0].start("text")] + "{{BODY}}" + t[rows[0].end("text"):]
        for r in list(BODY_ROW.finditer(t))[1:][::-1]:
            t = t[:r.start()] + t[r.end():]
    art = re.search(r'\s*<tr>\s*<td class="mp"[^>]*>\s*<a [^>]*>\s*<img[^>]*class="fluid-img"[^>]*>'
                    r'\s*</a>\s*</td>\s*</tr>', t)
    if art:          # no picture filed: the row goes, not just the image
        t = t[:art.start()] + "\n{{#IMG}}" + art.group(0) + "\n{{/IMG}}" + t[art.end():]
    t = re.sub(r'(letter-spacing:1\.5px;text-transform:uppercase;color:#ffffff;">)'
               r'[^<]*(</td>)', r'\g<1>{{CAT}}\g<2>', t)
    t = re.sub(r'(<span class="brief-hl"[^>]*>)[^<]*(</span>)', r'\g<1>{{HEAD}}\g<2>', t)
    t = re.sub(r'(line-height:23px;color:#3b4751;display:block;padding-top:8px;">)'
               r'[^<]*(</span>)', r'\g<1>{{BODY}}\g<2>', t)
    m = THUMB_CELL.search(t)
    # The runs below Editor's Picks carry no art by house rule, so a block
    # with no thumbnail cell is a second legitimate shape, not a failure.
    if m:
        t = t[:m.start()] + "\n{{#IMG}}" + m.group(0) + "{{/IMG}}\n" + t[m.end():]
    t = re.sub(r"<!-- STORY \d+[^>]*-->", "<!-- STORY -->", t)
    return t


def collapse_runs(s, run_names):
    """Replace each consecutive run of story blocks with one looping block."""
    spans = [m.span() for m in STORY.finditer(s)]
    assert spans, "no story blocks found"
    runs, cur = [], [spans[0]]
    for a, b in spans[1:]:
        gap = s[cur[-1][1]:a]
        if gap.strip() == "" or gap.strip().startswith("<!-- STORY"):
            cur.append((a, b))
        else:
            runs.append(cur); cur = [(a, b)]
    runs.append(cur)
    assert len(runs) == len(run_names), \
        f"found {len(runs)} story runs, named {len(run_names)}"
    for run, name in zip(reversed(runs), reversed(run_names)):
        start, end = run[0][0], run[-1][1]
        body = story_template(s[run[0][0]:run[0][1]])
        s = s[:start] + "{{#%s}}\n" % name + body + "{{/%s}}\n" % name + s[end:]
    return s


# ------------------------------------------------------------------- picks
CARD = re.compile(r'<div style="display:inline-block;width:100%;max-width:200px;[^"]*"[^>]*>.*?</div>', re.S)


def collapse_picks(s, items, flag, loop):
    cards = list(CARD.finditer(s))
    assert cards, "picks cards not found"
    src = items[0]
    card = cards[0].group(0)
    for key, field in (("img", "IMG"), ("url", "URL"), ("head", "HEAD"),
                       ("body", "BODY"), ("cat", "CAT")):
        assert src[key] in card, f"pick card lacks {key}"
        card = card.replace(src[key], "{{%s}}" % field)
    s = s[:cards[0].start()] + "{{#%s}}" % loop + card + "{{/%s}}" % loop + s[cards[-1].end():]
    return wrap(s, "5. EDITOR'S PICKS" if "5. EDITOR'S PICKS" in s else "EDITOR'S PICKS", flag)


# --------------------------------------------------------------------- ads
def text_ad_slots(s):
    """The slot numbers of the text ads actually in this file, in order."""
    return [int(m) for m in re.findall(r"AD (\d+) - TEXT AD WITH LOGO", s)]


def tokenise_text_ad(s, n):
    """A text ad block becomes a section over one hash.

    Matched on the block's own structure, not on the sample advertiser's copy:
    which content entry fills which slot differs per title and has already
    drifted once, and the markup is identical in every one of them.
    """
    a, b = block_span(s, f"AD {n} - TEXT AD WITH LOGO")
    blk = s[a:b]

    def logo(m):
        tag = re.sub(r'src="[^"]*"', 'src="{{logo}}"', m.group(0), count=1)
        return re.sub(r'alt="[^"]*"', 'alt="{{name}} logo"', tag, count=1)

    blk, k = re.subn(r'<img[^>]*class="ad-logo"[^>]*>', logo, blk, count=1)
    assert k == 1, f"ad {n}: logo not found"
    for pattern, field in (
            (r'(<span style="[^"]*font-size:21px;font-weight:700;[^"]*">)[^<]*(</span>)', "head"),
            (r'(<span style="[^"]*font-size:14px;color:#3b4751;[^"]*">)[^<]*(</span>)', "body"),
            # the CTA colour is per title - orange on AR, blue on SubPrime -
            # so match the role, not the hex
            (r'(<span style="[^"]*text-transform:uppercase;color:#[0-9a-fA-F]{3,6};'
             r'display:inline-block;[^"]*">)[^<]*(&#8250;</span>)', "cta")):
        blk, k = re.subn(pattern, r'\g<1>{{%s}}\g<2>' % field, blk, count=1)
        assert k == 1, f"ad {n}: {field} not found"
    blk = blk.replace("{{AD%d_URL}}" % n, "{{url}}")
    blk = renumber(blk, n)
    return s[:a] + "{{#AD%d}}\n" % n + blk + "{{/AD%d}}\n" % n + s[b:]


def renumber(blk, n):
    """Make a block's own comment agree with the slot it fills.

    PM reuses the AM in-content banner, which carried the comment
    "AD 4 - IN-CONTENT BANNER" into slot 3, so the file ended up with two
    blocks labelled AD 4. The label is the first thing a developer reads and
    it should not disagree with the field name right under it.
    """
    return re.sub(r"AD \d+\w* - ", f"AD {n} - ", blk, count=1)


def tokenise_banner(s, marker, n):
    a, b = block_span(s, marker)
    blk = s[a:b]

    def img(m):
        # each banner carries two images, and they are different creative
        field = "img_mobile" if "m-only" in m.group(0) else "img_desktop"
        tag = re.sub(r'src="[^"]*"', 'src="{{%s}}"' % field, m.group(0), count=1)
        return re.sub(r'alt="[^"]*"', 'alt="{{alt}}"', tag, count=1)

    blk, k = re.subn(r'<img\b[^>]*>', img, blk)
    if k == 1:
        # SubPrime's sample top banner has no mobile art yet, but the rate sheet
        # sells both for every banner, so the template offers both
        blk = blk.replace('class="fluid-img"', 'class="fluid-img d-only"', 1)
        blk = re.sub(r'(<img\b[^>]*>)',
                     r'''\g<1>
        <img src="{{img_mobile}}" width="375" alt="{{alt}}"
             class="m-only" style="width:100%;max-width:375px;height:auto;">''',
                     blk, count=1)
        k = 2
    assert k == 2 and "{{img_mobile}}" in blk and "d-only" in blk, \
        f"banner {n}: expected one desktop and one mobile image, found {k}"
    blk = re.sub(r"\{\{AD\d+_URL\}\}", "{{url}}", blk)
    blk = renumber(blk, n)
    return s[:a] + "{{#AD%d}}\n" % n + blk + "{{/AD%d}}\n" % n + s[b:]


# ----------------------------------------------------------- simple lists
def collapse_rows(s, marker, loop, flag, row_re, sep_re):
    """A heading + repeated rows becomes heading + one looping row.

    Every item after the first carries its own divider, so the data sets
    `sep` on all but the first item. Mustache has no index, and a flag in the
    data beats a divider that renders under the section heading.
    """
    a, b = block_span(s, marker)
    blk = s[a:b]
    rows = list(row_re.finditer(blk))
    assert len(rows) >= 2, f"{marker}: found {len(rows)} rows"
    seps = list(sep_re.finditer(blk))
    assert seps, f"{marker}: no dividers"
    body = rows[0].group(0)
    body = re.sub(r'(<span style="[^"]*text-transform:uppercase;color:#[0-9a-fA-F]{3,6};'
                  r'[^"]*">)[^<]*(</span>)', r'\g<1>{{CAT}}\g<2>', body)
    body = re.sub(r'<a href="[^"]*"', '<a href="{{URL}}"', body)
    body = re.sub(r'(text-decoration:none;">)[^<]*(</a>)', r'\g<1>{{HEAD}}\g<2>', body)
    body = body.replace('padding:0 0 0 0;', 'padding:12px 0 0 0;')
    sep = seps[0].group(0)
    loop_body = "{{#%s}}{{#sep}}%s{{/sep}}%s{{/%s}}" % (loop, sep, body, loop)
    start, end = rows[0].start(), rows[-1].end()
    blk = blk[:start] + loop_body + blk[end:]
    blk = sep_re.sub("", blk[:blk.index(loop_body)]) + blk[blk.index(loop_body):]
    s = s[:a] + blk + s[b:]
    return wrap(s, marker, flag)


HEAD_ROW = re.compile(
    r'\s*<tr>\s*<td style="padding:(?:0|12px) 0 0 0;">\s*<span style="[^"]*color:#[0-9a-fA-F]{3,6};[^"]*">'
    r'[^<]*</span>\s*<a href="[^"]*"[^>]*>[^<]*</a>\s*</td>\s*</tr>', re.S)
HEAD_SEP = re.compile(
    r'\s*<tr><td style="padding:12px 0 0 0;"><div style="height:1px;background-color:#dde2e7;'
    r'[^"]*">&nbsp;</div></td></tr>')


def finish(s, title, date, notes):
    s = sub1(s, date, "{{ISSUE_DATE}}", "issue date")
    banner = ("<!-- ============================================================\n"
              f"     {title} - BUILDER TEMPLATE\n"
              f"{notes}\n"
              "     ============================================================ -->\n")
    return banner + s


NOTE_AM = """     Mustache fields. A section renders once for a hash, once per item for a
     list, and not at all when the value is absent, false or an empty list -
     so an unsold ad position removes its whole block.
       AD1..AD7            {url, img_desktop, img_mobile, alt} for banners,
                           {url, logo, name, head, body, cta} for text ads
       LEAD_*              URL, CAT, HEAD, DECK, BYLINE, IMG, ALT, BODY(list)
       STORIES_1/2/3       runs between the fixed ad positions;
                           each item {URL, CAT, HEAD, BODY, IMG, ALT}
                           IMG empty drops the thumbnail cell
       HAS_PICKS + PICKS   {URL, CAT, HEAD, BODY, IMG}
       HAS_HEADLINES
         + HEADLINES       {URL, CAT, HEAD, sep} - sep true on all but the first
       HAS_PROMO + PROMO   the house promo {url, logo, when, head, body}
       ISSUE_DATE, ISSUE_URL, FORWARD_URL, RECIPIENT_EMAIL"""


def build_am():
    s = (BASE / "versions" / "theme-blue-darkflag.html").read_text(encoding="utf-8")
    s = tokenise_banner(s, "AD 1 - TOP LEADERBOARD", 1)
    s = tokenise_lead(s)
    s = loop_lead_body(s)
    for n in text_ad_slots(s):
        s = tokenise_text_ad(s, n)
    s = tokenise_banner(s, "AD 4 - IN-CONTENT BANNER", 4)
    s = collapse_runs(s, ["STORIES_1", "STORIES_2", "STORIES_3"])
    s = collapse_picks(s, C.PICKS, "HAS_PICKS", "PICKS")
    s = collapse_rows(s, "6. MORE HEADLINES", "HEADLINES", "HAS_HEADLINES",
                      HEAD_ROW, HEAD_SEP)
    s = tokenise_promo(s, C.UCW, "7. USED CAR WEEK PROMO")
    return finish(s, "AUTO REMARKETING TODAY (AM)", C.DATE, NOTE_AM)


def tokenise_promo(s, promo, marker):
    a, b = block_span(s, marker)
    blk = s[a:b]
    for key, field in (("logo", "logo"), ("url", "url"), ("when", "when"),
                       ("head", "head"), ("body", "body")):
        if promo.get(key) and promo[key] in blk:
            blk = blk.replace(promo[key], "{{%s}}" % field)
    return s[:a] + "{{#PROMO}}\n" + blk + "{{/PROMO}}\n" + s[b:]


def build_sp():
    s = (BASE / "subprime" / "versions" / "sp-blue-darkflag.html").read_text(encoding="utf-8")
    s = tokenise_banner(s, "AD 1 - TOP LEADERBOARD", 1)
    s = tokenise_lead(s)
    s = loop_lead_body(s)
    for n in text_ad_slots(s):
        s = tokenise_text_ad(s, n)
    # labelled "AD 3b" in the master; field AD4 is the free slot number
    s = tokenise_banner(s, "AD 3b - IN-CONTENT BANNER", 4)
    runs = len([1 for _ in re.finditer(r"<!-- STORY \d+", s)])
    s = collapse_runs(s, [f"STORIES_{i+1}" for i in range(_run_count(s))])
    s = collapse_picks(s, S.PICKS, "HAS_PICKS", "PICKS")
    if "MORE HEADLINES" in s:
        marker = next(m for m in ("6. MORE HEADLINES", "MORE HEADLINES") if m in s)
        s = collapse_rows(s, marker, "HEADLINES", "HAS_HEADLINES", HEAD_ROW, HEAD_SEP)
    if "USED CAR WEEK" in s:
        s = tokenise_promo(s, C.UCW, "USED CAR WEEK")
    return finish(s, "SUBPRIME NEWS UPDATE", S.DATE, NOTE_AM)


def _run_count(s):
    spans = [m.span() for m in STORY.finditer(s)]
    runs, cur = 0, None
    for a, b in spans:
        if cur is not None and (s[cur:a].strip() == "" or s[cur:a].strip().startswith("<!-- STORY")):
            pass
        else:
            runs += 1
        cur = b
    return runs


def build_pm():
    s = (BASE / "versions" / "ar-today-pm.html").read_text(encoding="utf-8")
    s = tokenise_banner(s, "AD 1 - TOP LEADERBOARD", 1)
    s = tokenise_lead(s)
    s = loop_lead_body(s)
    for n in text_ad_slots(s):
        s = tokenise_text_ad(s, n)
    if "IN-CONTENT BANNER" in s:
        s = tokenise_banner(s, "IN-CONTENT BANNER", 3)
    s = collapse_runs(s, [f"STORIES_{i+1}" for i in range(_run_count(s))])
    s = collapse_picks(s, P.WORTH, "HAS_PICKS", "PICKS")
    if "USED CAR WEEK" in s:
        s = tokenise_promo(s, C.UCW, "7. USED CAR WEEK")
    for marker, loop, flag in (("A. EARLIER TODAY", "EARLIER", "HAS_EARLIER"),
                               ("C. LATEST PODCASTS", "PODCASTS", "HAS_PODCASTS")):
        if marker in s:
            s = collapse_rows(s, marker, loop, flag, HEAD_ROW, HEAD_SEP)
    return finish(s, "AUTO REMARKETING TODAY PM", P.DATE, NOTE_AM)


if __name__ == "__main__":
    for name, fn in (("AR-Today-AM", build_am),
                     ("AR-Today-PM", build_pm),
                     ("SubPrime", build_sp)):
        out = OUT / f"{name}-template.html"
        try:
            html = fn()
        except Exception as e:
            print(f"{name}: FAILED {type(e).__name__}: {e}")
            continue
        out.write_text(html, encoding="utf-8")
        print(f"{name}: {len(html)//1024} kB  sections "
              f"{sorted(set(re.findall(r'\{\{#(\w+)\}\}', html)))}")
