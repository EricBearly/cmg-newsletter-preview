"""Where everything is, so the tools run from wherever the kit is unzipped."""
import os, pathlib, shutil

TOOLS = pathlib.Path(__file__).resolve().parent
BASE = TOOLS.parent / "newsletters"
PORT = os.environ.get("CMG_PORT", "8782")
(TOOLS / "preview").mkdir(exist_ok=True)


def _find_chrome():
    found = os.environ.get("CHROME")
    if found:
        return found
    for name in ("chrome", "google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
        hit = shutil.which(name)
        if hit:
            return hit
    for path in (r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                 r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                 "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"):
        if os.path.exists(path):
            return path
    raise SystemExit("Chrome not found. Set the CHROME environment variable to its path.")


CHROME = _find_chrome()
