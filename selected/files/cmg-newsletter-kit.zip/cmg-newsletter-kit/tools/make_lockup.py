"""One-image masthead: the full Auto Remarketing wordmark with Today beside it.

CMG's feedback (2026-11-09): keep the full title, not the AR initials; bigger,
bolder, and Today right alongside Auto Remarketing instead of across the page.

The wordmark is the official AR500.png (1893x500, black), recoloured white with
its alpha kept. Today is rendered in headless Chrome so the font is the real
web font, then scaled so its cap height matches the wordmark's cap height and
set on the same baseline, one wordmark word-space after the (R).

Two faces are rendered so CMG can pick:
  oswald  Oswald 700, the face Today already uses
  anton   Anton, a heavier condensed face closer to the wordmark's weight

Each lockup is scaled to fill the 602px content width, so the PM wordmark
comes out a little smaller than AM's: "pm" takes the difference.

Both faces land in lockup/ for comparison. The face in USE is also written,
without the face suffix, to the logos folders the masters point at.
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from paths import BASE, CHROME, PORT
import pathlib, re, subprocess, sys
import numpy as np
from PIL import Image

SCR = pathlib.Path(__file__).resolve().parent
SERVE = SCR / "serve"
OUT = SCR / "lockup"
OUT.mkdir(exist_ok=True)
USE = "anton"            # Option A, sent as the run-with version 2026-11-10
LOGO_DIRS = [SERVE / "logos", SCR / "preview" / "logos",
             BASE / "logos"]

ORANGE = "#f57c29"

# measured from AR500.png: the A runs rows 0-441, so cap height and baseline
# are both 441; the word space between Auto and Remarketing is 68px
WM_CAP, WM_BASE, WM_SPACE = 441, 441, 68
DISPLAY_W = 602          # content width of the 650 email
SCALE = 2                # images are 2x for retina

FACES = {"oswald": ("Oswald", "wght@700", "700"), "anton": ("Anton", "", "400")}
PM = '<span style="font-size:0.52em;letter-spacing:0.02em;">&nbsp;pm</span>'
WORDS = {"am": "Today", "pm": "Today" + PM}
BIG = 400                # render size; scaled down afterwards
# Today's cap height as a share of the wordmark's. 1.0 was the first sample;
# CMG asked for Today a little smaller (2026-11-09). Baselines stay aligned.
TODAY_SIZE = 0.85


def chrome(*args):
    return subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars",
                           "--virtual-time-budget=45000", *args],
                          capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180)


def render_text(face, inner):
    fam, axis, wt = FACES[face]
    q = f"family={fam}" + (f":{axis}" if axis else "")
    html = f"""<!doctype html><meta charset=utf-8>
<link href="https://fonts.googleapis.com/css2?{q}&display=block" rel="stylesheet">
<style>html,body{{margin:0;padding:0;background:transparent}}
#t{{display:inline-block;padding:120px 40px;font-family:'{fam}';font-size:{BIG}px;line-height:{BIG}px;
font-weight:{wt};color:{ORANGE};white-space:nowrap}}</style>
<div id=t>{inner}</div><pre id=r style="position:absolute;left:-9999px"></pre>
<script>document.fonts.load("{wt} {BIG}px {fam}").then(function(){{
var ok = document.fonts.check("{wt} {BIG}px {fam}");
var c = document.createElement("canvas").getContext("2d"); c.font = "{wt} {BIG}px {fam}";
var m = c.measureText("T"), w = c.measureText("Today");
document.getElementById("r").textContent = (ok ? "FONT_OK" : "FONT_MISSING") +
  " CAP=" + m.actualBoundingBoxAscent + " ASC=" + w.actualBoundingBoxAscent;}});</script>"""
    (SERVE / "lockupimg.html").write_text(html, encoding="utf-8")
    url = f"http://127.0.0.1:{PORT}/lockupimg.html"
    dom = chrome("--window-size=2400,700", "--dump-dom", url).stdout
    assert "FONT_OK" in dom, f"{face}: font did not load, refusing to bake a fallback"
    cap, asc = (float(v) for v in re.search(r"CAP=([\d.]+) ASC=([\d.]+)", dom).groups())
    raw = OUT / f"raw-{face}-{abs(hash(inner)) % 10000}.png"
    chrome("--default-background-color=00000000", "--window-size=2400,700", f"--screenshot={raw}", url)
    im = Image.open(raw).convert("RGBA")
    box = im.getbbox()
    assert box and box[0] > 0 and box[1] > 0 and box[2] < im.width and box[3] < im.height, f"{face}: ink at edge {box}"
    # the crop's top is the tallest ink in Today (the d), which sits ASC above
    # the baseline; the T's ascent is the cap height. Both from the font itself.
    return im.crop(box), cap, asc


wm = Image.open(SCR / "arlogo" / "AR500.png").convert("RGBA")
white = Image.new("RGBA", wm.size, (255, 255, 255, 0))
white.putalpha(wm.getchannel("A"))

texts = {(f, e): render_text(f, w) for f in FACES for e, w in WORDS.items()}

# one wordmark scale for both editions: the widest PM lockup must fit DISPLAY_W
def lockup_w(face, ed, k):
    t, cap, _ = texts[(face, ed)]
    r = WM_CAP * k * TODAY_SIZE / cap
    return wm.width * k + WM_SPACE * k + t.width * r

# each lockup fills the content width; 2px of slack absorbs rounding and the
# even-dimension crop so nothing lands at 603
for (face, ed), (t, cap, base) in texts.items():
    k = (DISPLAY_W - 1) * SCALE / lockup_w(face, ed, 1.0)
    print(f"{face} {ed}: wordmark {wm.width * k / SCALE:.0f}px wide at display size")
    r = WM_CAP * k * TODAY_SIZE / cap
    t2 = t.resize((round(t.width * r), round(t.height * r)), Image.LANCZOS)
    base2 = base * r
    w2 = white.resize((round(wm.width * k), round(wm.height * k)), Image.LANCZOS)
    wb = WM_BASE * k
    gap = round(WM_SPACE * k)
    top_t = round(wb - base2)        # Today's top relative to the wordmark's top
    y0 = min(0, top_t)
    H = max(w2.height, top_t + t2.height) - y0
    W = w2.width + gap + t2.width
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    canvas.alpha_composite(w2, (0, -y0))
    canvas.alpha_composite(t2, (w2.width + gap, top_t - y0))
    # even dimensions so the 1x size is exact
    canvas = canvas.crop((0, 0, W + W % 2, H + H % 2))
    name = f"AR-Today{'-PM' if ed == 'pm' else ''}-masthead-{face}.png"
    canvas.save(OUT / name, optimize=True)
    assert canvas.width // 2 <= DISPLAY_W, f"{name} is wider than the content column"
    if face == USE:
        for d in LOGO_DIRS:
            d.mkdir(parents=True, exist_ok=True)
            canvas.save(d / name.replace(f"-{face}", ""), optimize=True)
    print(name, "2x", canvas.size, "displays", (canvas.width // 2, canvas.height // 2),
          (OUT / name).stat().st_size // 1024, "kB")
