"""Real BHPH Report News content, pulled 21 Oct 2026 from
autoremarketing.com/bhph. Articles were read before these blurbs were written.
"""
BRAND = "BHPH Report News"
EDITION = "Tuesdays &amp; Thursdays"
DATE = "Wednesday, Oct. 21, 2026"
TAGLINE = "Buy Here, Pay Here news for independent dealers"
HEADER_IMG = "img/BHPHHeader.jpg"
SITE = "https://www.autoremarketing.com/bhph/"

LEAD = {
    "cat": "Credit",
    "url": "https://www.autoremarketing.com/bhph/bankruptcy-filings-through-three-quarters-top-460k/",
"img": "img/bhph-bankruptcy.jpg",
    "alt": "Bankruptcy filing paperwork",
    "head": "Bankruptcy filings through three quarters top 460K",
    "deck": "Whether the comparison is nine months or September alone, the year-over-year trend points the same way",
    "byline": "BHPH Report Staff &middot; Oct. 8",
    "body": "Bankruptcy filings are continuing to climb. Whether the comparison covers the first three quarters of the "
            "year or September on its own, the year-over-year figures show nearly the same upward trend, according to "
            "Epiq AACER data.",
}

BRIEFS = [
    {"cat": "Events",
     "url": "https://www.autoremarketing.com/bhph/niada-going-to-tiktok-to-close-upcoming-bhph-forum/",
     "img": "img/bhph-niada.jpg",
     "head": "NIADA going to TikTok to close upcoming BHPH Forum",
     "body": "TikTok Automotive principal Ryan Copacia will headline the closing general session of the National "
             "Independent Automobile Dealers Association&rsquo;s Buy Here, Pay Here Dealer Forum, held Nov. 1&ndash;3 "
             "in Austin, Texas."},
    {"cat": "Dealers",
     "url": "https://www.autoremarketing.com/bhph/buckeye-risk-services-welcomes-experienced-dealer-to-growing-team/",
"img": "img/bhph-brief1.jpg",
     "head": "Buckeye Risk Services welcomes experienced dealer to growing team",
     "body": "Buckeye Risk Services has added Mark Jones as business development manager, citing his nearly 40 years "
             "in the automotive business."},
    {"cat": "Retail",
     "url": "https://www.autoremarketing.com/bhph/next-car-mart-credit-deadline-hits-friday-amid-significant-progress/",
"img": "img/bhph-brief2.jpg",
     "head": "Next Car-Mart credit deadline hits Friday amid &lsquo;significant progress&rsquo;",
     "body": "America&rsquo;s Car-Mart faces another Friday deadline to secure further financial support, according to "
             "an SEC filing."},
]

WORTH = [
    {"cat": "Retail",
     "url": "https://www.autoremarketing.com/bhph/car-mart-retails-less-than-3k-vehicles-in-latest-quarter-reflecting-dire-capital-situation/",
     "img": "img/bhph-worth0.jpg",
     "head": "Car-Mart retails less than 3K vehicles in latest quarter, reflecting dire capital situation",
     "body": "First-quarter results for Car-Mart&rsquo;s 2027 fiscal year, and what they signal."},
    {"cat": "Credit",
     "url": "https://www.autoremarketing.com/bhph/august-bankruptcies-prompt-experts-to-project-more-increases-for-rest-of-2026-into-2027/",
     "img": "img/bhphpick1.jpg",
     "head": "August bankruptcies prompt experts to project more increases for rest of 2026 &amp; into 2027",
     "body": "August filings rose year-over-year across the board, according to Epiq AACER data highlighted by the American Bankruptcy Institute."},
    {"cat": "Commentary",
     "url": "https://www.autoremarketing.com/bhph/commentary-explaining-the-difference-between-a-consultation-versus-a-sales-pitch/",
     "img": "img/bhphpick2.jpg",
     "head": "COMMENTARY: Explaining the difference between a consultation versus a sales pitch",
     "body": "Is everything working as well as it can, and how would you know?"},
]

PODCASTS = [
    ("Oct. 21", "https://www.autoremarketing.com/soundcloud_feed/used-car-week-hall-of-fame-grace-huang-of-cox-automotive/",
     "Used Car Week Hall of Fame: Grace Huang of Cox Automotive"),
    ("Oct. 20", "https://www.autoremarketing.com/soundcloud_feed/ben-sporn-of-vip-automotive-group-takes-diy-approach-to-ai/",
     "Ben Sporn of VIP Automotive Group Takes DIY Approach to AI"),
    ("Oct. 20", "https://www.autoremarketing.com/soundcloud_feed/sponsored-podcast-securing-the-vehicle-handoff-with-secure-vehicle-transfer/",
     "SPONSORED PODCAST: Securing the Vehicle Handoff with Secure Vehicle Transfer"),
    ("Oct. 13", "https://www.autoremarketing.com/soundcloud_feed/sponsored-episode-high-quality-used-inventory-via-the-service-drive-with-autohubs-dan-gaughan/",
     "SPONSORED EPISODE: High-quality used inventory via the service drive with AutoHub&rsquo;s Dan Gaughan"),
]
