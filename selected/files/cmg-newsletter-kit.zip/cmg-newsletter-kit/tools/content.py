"""Shared content for the Auto Remarketing Today variants.

Every line of copy here is real: headlines, links, photography and summary text
come from autoremarketing.com and the Oct. 6 edition; sponsor copy comes from
each advertiser's own site and creative.
"""

AR = "https://www.autoremarketing.com"
UP = AR + "/wp-content/uploads"

DATE = "Tuesday, Oct. 6, 2026"
TAGLINE = "The News Media of the Pre-Owned Industry"

LEADERBOARD = dict(
    img="https://servedby.cherokeemediagroup2.com/zone_static/189881/image/0",
    url="{{AD1_URL}}")

LEAD = dict(
    cat="Wholesale",
    url=AR + "/ar/wholesale/wholesale-used-car-prices-drop-more-than-3-in-september/",
    img=UP + "/2025/12/shutterstock_2394434455-1.jpg",
    alt="A row of used vehicles parked on a wholesale lot",
    head="Wholesale used-car prices drop more than 3% in September",
    deck="Black Book&rsquo;s retention index fell 3.1% month-over-month, and the firm expects the slide to run through the fourth quarter",
    byline="Auto Remarketing Staff",
    body=[
        "The decline in wholesale vehicle prices grew steeper in September, and that downturn is likely to continue through the fourth quarter, according to the latest analysis from Black Book.",
        "On Monday, the firm released its latest Used Vehicle Retention Index, which fell 3.1% month-over-month in September and dropped 3.3% year-over-year. Granted, the decrease was not uniform, says Laura Wehunt, Black Book&rsquo;s vice president of data &amp; analytics.",
    ])

BRIEFS = [
    dict(cat="Retail",
         url=AR + "/ar/retail/dealers-asking-for-2-5-less-on-used-vehicles-than-they-were-a-month-ago/",
         img=UP + "/2026/09/shutterstock_2608375405.jpg",
         head="Dealers asking for 2.5% less on used vehicles than they were a month ago",
         body="Average asking prices for used vehicles listed by U.S. dealerships as of Saturday were down 2.5% from four weeks prior, with nearly three fifths of vehicles showing price cuts exceeding 0.5%. That&rsquo;s according to the first weekly national snapshot released by OAV.io, which bills itself as &ldquo;The Automotive Answer Engine.&rdquo;"),
    dict(cat="Retail",
         url=AR + "/ar/retail/dealership-ma-moves-from-mountain-west-to-atlantic-coast/",
         img=UP + "/2025/08/shutterstock_1094923718.jpg",
         head="Dealership M&amp;A moves from Mountain West to Atlantic Coast",
         body="Young Automotive Group has sold its Young Chrysler Dodge Jeep Ram and Young GMC dealerships in Burley, Idaho, to Mountain West Auto Group, according to Performance Brokerage Services, which advised on the sale. Young was founded in 1924 and now includes more than 30 automotive, powersports and truck &amp; trailer stores across Utah, Idaho and Montana."),
    dict(cat="Wholesale",
         url=AR + "/ar/wholesale/lane-watch-rising-fuel-costs-leaving-mark-on-values-volume-conversion-rate/",
         img=UP + "/2026/09/black-book-09-30-26-for-web.png",
         head="Lane watch: Rising fuel costs leaving mark on values, volume &amp; conversion rate",
         body="The newest Market Insights from Black Book watched overall wholesale values drop by 0.71% as depreciation continued at a seasonally elevated pace, with truck and SUV segments under greater pressure than cars. The auction conversion rate declined to 57%, a percentage point lower than the previous week."),
    dict(cat="Auctions",
         url=AR + "/ar/wholesale/naaa-names-next-leadership-rotation-hall-of-fame-inductee-industry-pioneer-more/",
         img=UP + "/2026/10/NAAA.jpg",
         head="NAAA names next leadership rotation, Hall of Fame inductee, Industry Pioneer &amp; more",
         body="At its World Remarketing Convention in Seattle, the National Auto Auction Association elected Lisa Franz as its vice president for the 2026-2027 term. This begins a four-year leadership progression for Franz, who is general manager and co-founder of Big Valley Auto Auction in Donna, Texas, which she and her family opened in 2008."),
    dict(cat="Technology",
         url=AR + "/ar/technology/itochu-invests-in-moter-again-to-leverage-connected-car-technology/",
         img=UP + "/2026/09/itochu-moter-for-web.png",
         head="ITOCHU invests in MOTER again to leverage connected-car technology",
         body="If you didn&rsquo;t believe the modern vehicles you&rsquo;re financing, retailing or repairing are smartphones rolling on four wheels, perhaps this investment announcement will sway your opinion. MOTER Technologies, an AI-powered insurtech delivering a connected-vehicle data platform, said it gained an additional strategic investment from ITOCHU Corp., one of Japan&rsquo;s leading general trading companies."),
    dict(cat="Technology",
         url=AR + "/ar/technology/with-ai-agent-adoption-growing-igniteups-ai-rolls-out-one-with-critical-dealership-tasks-in-mind/",
         img=UP + "/2026/10/IgniteUps-for-web.png",
         head="With AI agent adoption growing, IgniteUps.ai rolls out one with critical dealership tasks in mind",
         body="The company introduced NEXUS, designed to be an automotive AI performance manager built to orchestrate a dealership&rsquo;s connected AI workforce and execute real work across its systems. &ldquo;Every dealership manager has asked, &lsquo;What can we do to sell a car today?&rsquo; NEXUS is built to help answer that question and then help execute,&rdquo; founder and CEO Chris Martinez said."),
    dict(cat="Data &amp; Analysis",
         url=AR + "/ar/analysis/commentary-dealers-dont-have-an-inventory-problem-they-have-a-decision-problem/",
         img=UP + "/2023/01/cars-in-showroom_43.jpg",
         head="COMMENTARY: Dealers don&rsquo;t have an inventory problem; they have a decision problem",
         body="The past several years reshaped the economics of automotive retail, creating operating conditions that were never likely to last. Dealers who thrived on thin supply and outsized margins are now addressing a harder environment: rising floorplan costs, more price-sensitive consumers and compressed per-vehicle gross."),
]

PICKS = [
    dict(cat="Data &amp; Analysis",
         url=AR + "/ar/analysis/jd-power-brand-loyalty-stays-strong-amid-economic-headwinds/",
         img=UP + "/2025/11/54933604619_4651784776_o.jpg",
         head="JD Power: Brand loyalty stays strong amid economic headwinds",
         body="Loyalty averaged 50.2% across all nameplates and segments, up from 49% a year ago."),
    dict(cat="Technology",
         url=AR + "/ar/technology/drivecentric-introduces-acquire-agent-for-real-time-vehicle-acquisition/",
         img=UP + "/2025/06/DriveCentric-NIADA-2024-3.jpg",
         head="DriveCentric introduces Acquire Agent for real-time acquisition",
         body="The company started October by adding to its growing portfolio of native AI agents."),
    dict(cat="Data &amp; Analysis",
         url=AR + "/ar/analysis/meet-the-40-under-40-industry-honorees-for-2026/",
         img=UP + "/2026/09/40-40logo.jpg",
         head="Meet the &lsquo;40 Under 40: Industry&rsquo; honorees for 2026",
         body="The latest installment of Auto Remarketing&rsquo;s 40 Under 40 franchise."),
]

ADS = [
    dict(n=2, logo="logos/acertified.png", name="AcertiFied",
         head="No code. No car.",
         body="ACERTified verifies driver identity at the pickup stage of vehicle transport. Your designated release agent and the assigned driver confirm a text code two ways; if it matches, the system greenlights release and both sides get a digital confirmation. A first-of-its-kind safeguard against pickup-stage fraud, from the largest automotive logistics platform in North America.",
         cta="Learn more"),
    dict(n=3, logo="logos/360booth.png", name="360Booth",
         head="The world&rsquo;s most sold photo studio",
         body="Your photo studio is ready. Are you? The patented 360Booth moves around the vehicle 360 degrees, so you don&rsquo;t have to reposition a thing. Studio-quality, professional-looking photos with your dealership&rsquo;s branding built into every image, shot the same way every time.",
         cta="See the booth"),
    dict(n=4, logo="logos/carolina.png", name="Carolina Auto Auction",
         head="Sales every Wednesday at 9:00 a.m.",
         body="Join us every Wednesday at 9:00 a.m. for exciting promos and sales, and mark your calendar for the 2026 Dealer Appreciation Sale on Dec. 16. &ldquo;At Carolina Auto Auction we have a special relationship with our dealers. We provide a superior customer experience for everyone who walks through our doors.&rdquo;",
         cta="See the sale calendar"),
    dict(n=5, logo="logos/mia.png", name="mia",
         head="One dealership. One month of outbound.",
         body="2,000+ customers reached, 500+ appointments booked and $250K+ in attributed revenue &mdash; fully automated, from first call to booked appointment. mia is a 24/7 automotive AI phone agent covering reception, sales, service and outbound, replacing fragmented tech with one platform built to deliver ROI from the first conversation.",
         cta="Get results like these"),
    dict(n=6, logo="logos/protomiq.png", name="Protomiq",
         head="Know more before you make the first call",
         body="The IQ Advantage: recommended strategy, disposable income, distance to dealer, site viewed VDPs and much, much more. Protomiq is the conversion and experience platform for auto dealers, turning shopper behavior &mdash; searches, trade valuations, payment calculations &mdash; into purchase intent your sales and service teams can act on.",
         cta="Learn more"),
    dict(n=7, logo="logos/cdk.png", name="CDK",
         head="Win with your cards face-up",
         body="Show car buyers you have nothing up your sleeve. $540 billion in automotive commerce runs through CDK dealership software and systems every year &mdash; unrivaled scale, deep industry expertise and a record of innovation that helps dealers fuel growth, increase efficiency and achieve stronger business results.",
         cta="Win with CDK"),
]

HEADLINES = [
    ("Auctions", AR + "/ar/wholesale/4-naaa-chapter-presidents-honored-as-warren-young-fellows/",
     "4 NAAA Chapter presidents, ConditionReports.com exec &amp; NIADA CEO honored as Warren Young Fellows"),
    ("Wholesale", AR + "/ar/wholesale/commentary-the-same-analytics-divide-reshaping-sports-is-now-reshaping-vehicle-acquisition/",
     "COMMENTARY: The same analytics divide reshaping sports is now reshaping vehicle acquisition"),
    ("Retail", AR + "/ar/retail/lithia-names-chief-people-officer/",
     "Lithia names chief people officer"),
    ("Auctions", AR + "/ar/wholesale/manheim-approaches-2m-in-annual-fundraising-for-boys-girls-clubs/",
     "Manheim approaches $2M in annual fundraising for Boys &amp; Girls Clubs"),
]

UCW = dict(
    logo="https://usedcarweek.biz/wp-content/uploads/UCW2026_Logo.png",
    url="https://usedcarweek.biz/",
    when="Nov. 16&ndash;19 &middot; Manchester Grand Hyatt, San Diego",
    head="Dealers attend Used Car Week free",
    body="Speakers from AutoNation, Lithia &amp; Driveway, West Herr, Napleton, Carvana, CarMax and more on used EVs, mobile service, CPO, leadership strategy, tech investment and M&amp;A.")

NETWORK = [("AR Canada", AR + "/arcanada"), ("SubPrime", AR + "/subprime"),
           ("BHPH Report", AR + "/bhph"), ("Auto Fin Journal", AR + "/autofinjournal")]
SERVICES = [("Podcasts", AR + "/podcast"), ("CMG Premium", AR + "/subscription-options"),
            ("Digital Magazine", "https://digital.autoremarketing.com/")]
ADDRESS = "701 Cascade Pointe Lane, Cary, NC 27513"
