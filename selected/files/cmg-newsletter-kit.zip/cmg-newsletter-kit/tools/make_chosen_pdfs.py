"""The chosen design, one PDF per brand: desktop page, then mobile page.

Same format as the full-views decks already signed off - 13in-wide pages, each
page one whole email at a readable size, no cover.

Why per brand and not one combined file: both brands in one PDF forces one page
size, and because SubPrime is the SHORT email it becomes the widest column when
scaled to a common height. That pushed the page to 16in x 96in, which left the
cover stranded on a 96in sheet with ~84in of blank below it and made the thing
look broken. Sizing each brand's pages off its own emails avoids all of that.
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from paths import BASE, CHROME
import pathlib, subprocess, base64
from PIL import Image


SPDIR = BASE / "subprime"
SCR = pathlib.Path(__file__).parent
BUILD = SCR / "pdfbuild"
BUILD.mkdir(exist_ok=True)


PAGE_W_IN, MARGIN_IN, HEADER_PX = 13, 0.5, 190
MAX_W = (PAGE_W_IN - 2 * MARGIN_IN) * 96
FIT = 0.90          # keep the widest render comfortably inside the text width

JOBS = [
    ("AR-Today-newsletter.pdf", "Auto Remarketing Today", BASE, BASE, [
        ("theme-blue-darkflag", "Blue, dark masthead"),
    ]),
    ("AR-Today-PM-newsletter.pdf", "Auto Remarketing Today PM", BASE, BASE, [
        ("ar-today-pm", "Blue, dark masthead · afternoon edition"),
    ]),
    ("AR-Canada-newsletter.pdf", "Auto Remarketing Canada", BASE, BASE, [
        ("ar-canada", "Weekly edition"),
    ]),
    ("BHPH-Report-newsletter.pdf", "BHPH Report News", BASE, BASE, [
        ("bhph-report", "Tuesdays and Thursdays"),
    ]),
    ("Auto-Fin-Journal-newsletter.pdf", "Auto Fin Journal", BASE, BASE, [
        ("auto-fin-journal", "Mondays and Wednesdays"),
    ]),
    ("SubPrime-newsletter.pdf", "SubPrime News Update", SPDIR, SPDIR, [
        ("sp-blue-darkflag", "Blue, dark flag"),
    ]),
]

_n = [0]


def b64(img, cap, q=82):
    _n[0] += 1
    if img.width > cap:
        img = img.copy()
        img.thumbnail((cap, 2000000), Image.LANCZOS)
    p = BUILD / f"sl{_n[0]}.jpg"
    img.convert("RGB").save(p, "JPEG", quality=q, optimize=True, progressive=True)
    return "data:image/jpeg;base64," + base64.b64encode(p.read_bytes()).decode()


for outname, brand, root, _r2, options in JOBS:
    shots = []
    for vid, kind in options:
        d = Image.open(root / "samples" / "print" / f"{vid}.png").convert("RGB")
        m = Image.open(root / "samples" / f"{vid}-phone.png").convert("RGB")
        shots.append((vid, kind, d, m))

    CONTENT_H = int(FIT * min(min(im.height * MAX_W / im.width for im in (d, m))
                              for _, _, d, m in shots))
    pages = []
    for i, (vid, kind, d, m) in enumerate(shots, start=1):
        dw = round(d.width * CONTENT_H / d.height)
        mw = round(m.width * CONTENT_H / m.height)
        assert dw <= MAX_W and mw <= MAX_W, f"{vid}: {dw}/{mw} > {MAX_W}"
        for label, meta, img, cap, w in (
                ("Desktop", "650px wide, full length", d, 1460, dw),
                ("Mobile", "375px wide, full length", m, 750, mw)):
            pages.append(f"""
<section class="page">
  <div class="hd">
    <div><h2>{brand}</h2><p class="kind">{kind}</p></div>
    <p class="meta">{label} &middot; {meta}</p>
  </div>
  <div class="stage"><img style="width:{w}px" src="{b64(img, cap=cap)}"></div>
</section>""")
        print(f"  {i:02d} {vid:22s} desktop {dw}px | mobile {mw}px")

    PAGE_H_IN = (CONTENT_H + HEADER_PX) / 96.0
    html = f"""<!doctype html><html><head><meta charset="utf-8"><title>{brand} - shortlist full views</title>
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;600;700&family=Open+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
  @page {{ size: {PAGE_W_IN}in {PAGE_H_IN:.2f}in; margin: 0.45in {MARGIN_IN}in; }}
  *{{box-sizing:border-box}}
  html,body{{margin:0;padding:0}}
  body{{font-family:'Open Sans',Arial,sans-serif;color:#0f1419;
    -webkit-print-color-adjust:exact;print-color-adjust:exact}}
  .page{{page-break-after:always;break-after:page}}
  .page:last-child{{page-break-after:auto;break-after:auto}}
  .hd{{display:flex;align-items:center;gap:14px;border-bottom:3px solid #0f1419;
    padding-bottom:8px;margin-bottom:16px}}
  .num{{font-family:'Oswald',Arial,sans-serif;font-size:32px;font-weight:700;color:#f57c29;line-height:1}}
  .hd h2{{font-family:'Oswald',Arial,sans-serif;font-size:24px;font-weight:700;letter-spacing:2px;
    text-transform:uppercase;margin:0;line-height:1.1}}
  .kind{{font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:#8a949e;margin:3px 0 0;font-weight:700}}
  .meta{{margin:0 0 0 auto;font-family:'Oswald',Arial,sans-serif;font-size:13px;font-weight:600;
    letter-spacing:1.8px;text-transform:uppercase}}
  .stage{{display:flex;justify-content:center}}
  .stage img{{display:block;border:1px solid #cfd6dd;height:auto}}
</style></head><body>
{''.join(pages)}
</body></html>"""

    src = BUILD / outname.replace(".pdf", ".html")
    src.write_text(html, encoding="utf-8")
    out = BASE / outname
    subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--no-pdf-header-footer",
                    "--virtual-time-budget=90000", f"--print-to-pdf={out}", src.as_uri()],
                   capture_output=True)
    print(f"{outname}: page {PAGE_W_IN}in x {PAGE_H_IN:.1f}in, {len(pages)} pages, "
          f"{out.stat().st_size // 1024} KB\n")
