"""Real Auto Remarketing Canada content, pulled 21 Oct 2026.

Stories come from autoremarketing.com/canada and each article was read before
the blurb was written. The podcast episodes are the Auto Remarketing Podcast
feed, which AR Canada's own newsletter also carries.
"""

BRAND = "Auto Remarketing Canada"
EDITION = "Weekly"
DATE = "Wednesday, Oct. 21, 2026"
TAGLINE = "The News Media of the Pre-Owned Industry"
HEADER_IMG = "img/ARCanadaWeekly.png"
SITE = "https://www.autoremarketing.com/canada/"

LEAD = {
    "cat": "Values",
    "url": "https://www.autoremarketing.com/arcanada/toyota-tops-cbb-best-retained-value-awards-for-10th-straight-year-sweeps-3-categories/",
    "img": "img/arc-toyota.jpg",
    "alt": "2023 Toyota Tundra",
    "head": "Toyota tops CBB Best Retained Value Awards for 10th straight year, sweeps 3 categories",
    "deck": "Porsche led the premium category and Kia led electric vehicles in Canadian Black Book&rsquo;s 2026 awards",
    "byline": "Auto Remarketing Canada Staff &middot; Oct. 20",
    "body": "Canadian Black Book named Toyota the winner in the mainstream category of its 2026 Best Retained Value "
            "Awards, with Porsche top of the premium category and Kia leading electric vehicles. Toyota has now been "
            "the top mainstream brand for retained value for 10 consecutive years, and took first, second and third "
            "place in three categories: Car: Mainstream, SUV: Mainstream Sub-Compact/Compact and SUV: Mainstream "
            "Mid/Full-size.",
}

BRIEFS = [
    {"cat": "Wholesale",
     "url": "https://www.autoremarketing.com/arcanada/wholesale-vehicle-price-declines-nearly-triple-last-week/",
"img": "img/arc-wholesale.jpg",
     "head": "Wholesale vehicle price declines nearly triple last week",
     "body": "Canadian wholesale vehicle values fell almost three times as fast last week, with average depreciation "
             "rising from 0.12% to 0.35%, according to Canadian Black Book&rsquo;s latest Market Insights report. The "
             "average decline for the same week across 2017 to 2019 was 0.19%."},
]

WORTH = [
    {"cat": "Retail",
     "url": "https://www.autoremarketing.com/arcanada/awin-group-of-dealerships-names-former-bmw-canada-ceo-as-new-coo/",
     "img": "img/arc-worth0.jpg",
     "head": "AWIN Group of Dealerships names former BMW Canada CEO as new COO",
     "body": "The Vaughan, Ontario dealer group hired Reiner Braun, most recently president and chief executive of BMW Group Latin America."},
    {"cat": "Retail",
     "url": "https://www.autoremarketing.com/arcanada/dilawri-opens-third-kia-store-in-ontario/",
     "img": "img/arcpick1.jpg",
     "head": "Dilawri opens third Kia store in Ontario",
     "body": "The dealer group, said to be Canada&rsquo;s largest, has opened Kia Vaughan, expanding its Kia footprint in the province."},
    {"cat": "Dealer groups",
     "url": "https://www.autoremarketing.com/arcanada/autocanada-to-conduct-strategic-review-of-collision-operations/",
     "img": "img/arcpick2.jpg",
     "head": "AutoCanada to conduct strategic review of collision operations",
     "body": "The board has initiated a review of the company&rsquo;s collision business, handled by a special committee of independent directors."},
]

PODCASTS = [
    ("Oct. 21", "https://www.autoremarketing.com/soundcloud_feed/used-car-week-hall-of-fame-grace-huang-of-cox-automotive/",
     "Used Car Week Hall of Fame: Grace Huang of Cox Automotive"),
    ("Oct. 20", "https://www.autoremarketing.com/soundcloud_feed/ben-sporn-of-vip-automotive-group-takes-diy-approach-to-ai/",
     "Ben Sporn of VIP Automotive Group Takes DIY Approach to AI"),
    ("Oct. 20", "https://www.autoremarketing.com/soundcloud_feed/sponsored-podcast-securing-the-vehicle-handoff-with-secure-vehicle-transfer/",
     "SPONSORED PODCAST: Securing the Vehicle Handoff with Secure Vehicle Transfer"),
    ("Oct. 13", "https://www.autoremarketing.com/soundcloud_feed/sponsored-episode-high-quality-used-inventory-via-the-service-drive-with-autohubs-dan-gaughan/",
     "SPONSORED EPISODE: High-quality used inventory via the service drive with AutoHub&rsquo;s Dan Gaughan"),
]
