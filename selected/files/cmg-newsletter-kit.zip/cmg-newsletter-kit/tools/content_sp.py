"""SubPrime News Update content, mapped field-for-field onto the AR structure.

Stories, photography, links and summary copy are real, from the SubPrime
channel on autoremarketing.com and the Oct. 7 Subprime News Update. Sponsor
copy is taken from each advertiser's own creative in that issue.
"""

SP = "https://www.autoremarketing.com/subprime"
UP = "https://www.autoremarketing.com/wp-content/uploads"

DATE = "Wednesday, Oct. 7, 2026"
TAGLINE = "Auto Finance News"
WORDMARK = "News Update"

LEAD = dict(
    cat="Compliance",
    url=SP + "/ftc-dismisses-payment-packing-complaint-against-asbury-2-years-after-initial-filing/",
    img=UP + "/2026/04/Asbury-logo.jpg",
    alt="Asbury Automotive Group",
    head="FTC dismisses &lsquo;payment packing&rsquo; complaint against Asbury 2 years after initial filing",
    deck="The dealer group called the allegations &lsquo;false and unfounded&rsquo; in 2024; the commission has now dropped its bid for permanent injunctive relief",
    byline="SubPrime Auto Finance News Staff",
    body=[
        "In August 2024, Asbury Automotive Group rejected &ldquo;false and unfounded&rdquo; allegations by the Federal Trade Commission of &ldquo;payment packing&rdquo; at three of its dealerships in the Dallas-Fort Worth area.",
        "On Monday, the FTC dismissed the complaint that sought permanent injunctive relief.",
    ])

BRIEFS = [
    dict(cat="Credit Data",
         url=SP + "/experian-cashflow-data-bureau-designed-to-responsibly-expand-access-to-credit/",
         img=UP + "/2026/10/Experian-cashflow-data-bureau-for-web.jpg",
         head="Experian Cashflow Data Bureau designed to responsibly expand access to credit",
         body="The newest Experian product puts a technology spin on the old saying, &ldquo;Cash is king.&rdquo; On Tuesday, the company launched Experian Cashflow Data Bureau, a new consumer reporting agency that operates under the Fair Credit Reporting Act."),
    dict(cat="Originations",
         url=SP + "/edmunds-spots-6-new-records-as-average-amounts-financed-payments-terms-keep-growing-in-q3/",
         img=UP + "/2026/10/Edmunds-Q3-2026-for-web.png",
         head="Edmunds spots 6 new records as average amounts financed, payments &amp; terms keep growing in Q3",
         body="Among the six records highlighted in the latest analysis Edmunds released about third-quarter activity, 6.5% of used-vehicle buyers who needed financing took on monthly payments of $1,000 or more. That&rsquo;s up from 6.3% in Q2 and 6.1% in Q3 of last year."),
    dict(cat="Refinancing",
         url=SP + "/ilending-suspends-auto-refinancing-with-new-customers/",
         img=UP + "/2022/09/ilending-logo_0_0_0.png",
         head="iLending suspends auto refinancing with new customers",
         body="In June, iLending president Nick Goraczkowski discussed the prospects for auto refinancing, saying: &ldquo;We&rsquo;re seeing pockets of strength that are creating opportunity but also reinforcing how quickly conditions can change.&rdquo; A dramatic change arrived Thursday as the company said it had suspended refinancing loans for new customers."),
    dict(cat="Industry",
         url=SP + "/afsa-bloomberg-missed-important-perspective-in-recent-analysis-of-subprime-auto-finance/",
         img=UP + "/2026/10/AFSA-logo-for-web.png",
         head="AFSA: Bloomberg missed &lsquo;important perspective&rsquo; in recent analysis of subprime auto finance",
         body="The American Financial Services Association took issue with significant portions of a Bloomberg article published this week. The report recapped an examination of nearly 3 million subprime auto loans packaged into securities between 2021 and 2023, tracing how some finance companies work with contract holders who are delinquent."),
    # below Editor's Picks - text only
    dict(cat="Economy",
         url=SP + "/economic-experts-on-why-story-is-not-any-single-data-point/",
         img=UP + "/2023/01/another-couple-paying-bills_3.jpg",
         head="Economic experts on why &lsquo;story is not any single data point&rsquo;",
         body="The confluence of soaring costs of gas and food and sagging consumer confidence is further deteriorating the environment for dealerships and finance companies. That&rsquo;s one conclusion to be drawn from analysis recently provided by Cox Automotive, Fifth Third Bank and the Conference Board."),
    dict(cat="Servicing",
         url=SP + "/3-primary-capabilities-of-paynearmes-ai-servicing-and-collections-agent/",
         img=UP + "/2026/01/Artificial-intelligence-AI.jpg",
         head="3 primary capabilities of PayNearMe&rsquo;s AI Servicing and Collections Agent",
         body="A month after acquiring the technology assets of Marr Labs, PayNearMe launched its AI Servicing and Collections Agent, a new solution built directly into PayXM to improve payment collection and account servicing."),
    dict(cat="Technology",
         url=SP + "/sc-broadens-deployment-of-electronic-vehicle-titles-with-champ/",
         img=UP + "/2026/01/CHAMP-at-UCW-2025.jpg",
         head="SC broadens deployment of electronic vehicle titles with CHAMP",
         body="CHAMP said it now provides the electronic titling technology supporting South Carolina&rsquo;s Digital Government Services initiative with Tyler Technologies, enabling electronic vehicle titles for dealer reassignment transactions."),
]

PICKS = [
    dict(cat="Risk",
         url=SP + "/5-takeaways-from-transunion-report-examining-debt-settlements/",
         img=UP + "/2026/09/TransUnion-debt-settlement-report-for-web.png",
         head="5 takeaways from TransUnion report examining debt settlements",
         body="Analysts explored consumer behavior before and after enrollment in third-party debt settlement."),
    dict(cat="Refinancing",
         url=SP + "/origence-deepens-refinancing-presence-with-newest-solution/",
         img=UP + "/2026/10/hello-refi-for-web.png",
         head="Origence deepens refinancing presence with newest solution",
         body="A new auto refinance solution built to help credit unions capture more contract opportunities."),
    dict(cat="Servicing",
         url=SP + "/3-primary-capabilities-of-paynearmes-ai-servicing-and-collections-agent/",
         img=UP + "/2026/01/Artificial-intelligence-AI.jpg",
         head="PayNearMe builds an AI agent into servicing and collections",
         body="Three capabilities aimed at improving payment collection and account servicing."),
]

LEADERBOARD = dict(img="https://servedby.cherokeemediagroup2.com/zone_static/189835/image/0", url="{{AD1_URL}}")

ADS = [
    dict(n=2, logo="splogos/allied.png", name="Allied Solutions",
         head="Future-proof your auto finance business",
         body="Unleash innovation as your secret weapon. Allied Solutions works with finance companies on the insurance, risk and technology side of the business.",
         cta="Learn more"),
    dict(n=3, logo="splogos/par.png", name="PAR",
         head="2.5M+ vehicles recovered",
         body="PAR is the recovery management platform behind millions of completed assignments, connecting finance companies with a vetted national agent network.",
         cta="See the network"),
    dict(n=4, logo="splogos/statenational.png", name="State National",
         head="The difference is in the details",
         body="Compliance details that protect your business. State National works with lenders on collateral protection and portfolio risk.",
         cta="Explore now"),
    dict(n=5, logo="splogos/recoveryconnect.png", name="Recovery Connect by MBSi",
         head="Get more cars, faster",
         body="Recovery Connect by MBSi Corp connects lenders and recovery agents on one compliant platform, moving assignments faster from placement to recovery.",
         cta="See how it works"),
    dict(n=6, logo="splogos/blackbook.png", name="Black Book",
         head="Stay on top of residual value insights",
         body="Black Book tracks residual values and depreciation across the market, so originations, servicing and remarketing teams price from the same book.",
         cta="Subscribe"),
]

HEADLINES = [
    ("Compliance", SP + "/ftc-dismisses-payment-packing-complaint-against-asbury-2-years-after-initial-filing/",
     "FTC dismisses &lsquo;payment packing&rsquo; complaint against Asbury 2 years after initial filing"),
    ("Risk", SP + "/5-takeaways-from-transunion-report-examining-debt-settlements/",
     "5 takeaways from TransUnion report examining debt settlements"),
    ("Refinancing", SP + "/origence-deepens-refinancing-presence-with-newest-solution/",
     "Origence deepens refinancing presence with newest solution"),
    ("Industry", SP + "/afsa-bloomberg-missed-important-perspective-in-recent-analysis-of-subprime-auto-finance/",
     "AFSA: Bloomberg missed &lsquo;important perspective&rsquo; in recent analysis of subprime auto finance"),
]
