"""Render each builder template twice and check what came out.

A template nobody has rendered is a guess. This fills one with real data and
one with no ads at all, then checks three things: no merge field survives the
render, the sold version carries every ad, and the unsold version carries none
of them and still closes all its tables.
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from paths import BASE
import pathlib, re, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent))
import content as C, content_pm as P, content_sp as S
from mustache import render


TPL = BASE / "templates"
SERVE = pathlib.Path(__file__).parent / "serve"


def paras(body):
    """LEAD_BODY is a list of paragraphs; some modules already hold a list."""
    return body if isinstance(body, (list, tuple)) else [body]


def story(d, sep=False):
    out = {"URL": d["url"], "CAT": d["cat"], "HEAD": d["head"],
           "BODY": d.get("body", ""), "IMG": d.get("img", ""), "ALT": d.get("alt", "")}
    if sep:
        out["sep"] = True
    return out


def text_ad(a):
    return {"url": "https://example.com/ad", "logo": a["logo"], "name": a["name"],
            "head": a["head"], "body": a["body"], "cta": a["cta"]}


def banner():
    return {"url": "https://example.com/ad", "alt": "Advertisement",
            "img_desktop": "img/leaderboard-189881.png",
            "img_mobile": "img/leaderboard-189881-mobile.png"}


def rows(items):
    """EARLIER / PODCASTS / HEADLINES tuples -> field hashes."""
    out = []
    for i, t in enumerate(items):
        cat, url, head = t[0], t[1], t[2]
        r = {"CAT": cat, "URL": url, "HEAD": head}
        if i:
            r["sep"] = True
        out.append(r)
    return out


def data_for(kind):
    if kind == "AM":
        ads = {a["n"]: a for a in C.ADS}
        d = {"ISSUE_DATE": C.DATE, "ISSUE_URL": "https://example.com/issue",
             "FORWARD_URL": "https://example.com/forward",
             "RECIPIENT_EMAIL": "reader@example.com",
             "LEAD_URL": C.LEAD["url"], "LEAD_CAT": C.LEAD["cat"],
             "LEAD_HEAD": C.LEAD["head"], "LEAD_DECK": C.LEAD["deck"],
             "LEAD_BYLINE": C.LEAD["byline"], "LEAD_IMG": C.LEAD["img"],
             "LEAD_ALT": C.LEAD["alt"], "LEAD_BODY": paras(C.LEAD["body"]),
             "STORIES_1": [story(b) for b in C.BRIEFS[:2]],
             "STORIES_2": [story(b) for b in C.BRIEFS[2:4]],
             "STORIES_3": [story(dict(b, img="")) for b in C.BRIEFS[4:7]],
             "HAS_PICKS": True, "PICKS": [story(p) for p in C.PICKS],
             "HAS_HEADLINES": True, "HEADLINES": rows(C.HEADLINES),
             "PROMO": dict(C.UCW),
             "AD1": banner(), "AD4": banner()}
        for n in (2, 3, 5, 6, 7):
            d[f"AD{n}"] = text_ad(ads[n if n in ads else 2])
        return d
    if kind == "PM":
        ads = {a["n"]: a for a in C.ADS}
        d = {"ISSUE_DATE": P.DATE, "ISSUE_URL": "https://example.com/issue",
             "FORWARD_URL": "https://example.com/forward",
             "RECIPIENT_EMAIL": "reader@example.com",
             "LEAD_URL": P.LEAD["url"], "LEAD_CAT": P.LEAD["cat"],
             "LEAD_HEAD": P.LEAD["head"], "LEAD_DECK": P.LEAD["deck"],
             "LEAD_IMG": P.LEAD["img"], "LEAD_ALT": P.LEAD.get("alt", ""),
             "LEAD_BODY": paras(P.LEAD["body"]),
             "STORIES_1": [story(b) for b in P.BRIEFS],
             "HAS_PICKS": True, "PICKS": [story(p) for p in P.WORTH],
             "HAS_EARLIER": True, "EARLIER": rows(P.EARLIER),
             "HAS_PODCASTS": True, "PODCASTS": rows([("Podcast", u, h) for _, u, h in P.PODCASTS]),
             "PROMO": dict(C.UCW), "AD1": banner(), "AD3": banner()}
        for n in (2, 4, 5, 6):
            d[f"AD{n}"] = text_ad(ads[2])
        return d
    ads = {a["n"]: a for a in S.ADS}
    d = {"ISSUE_DATE": S.DATE, "ISSUE_URL": "https://example.com/issue",
         "FORWARD_URL": "https://example.com/forward",
         "RECIPIENT_EMAIL": "reader@example.com",
         "LEAD_URL": S.LEAD["url"], "LEAD_CAT": S.LEAD["cat"],
         "LEAD_HEAD": S.LEAD["head"], "LEAD_DECK": S.LEAD["deck"],
         "LEAD_BYLINE": S.LEAD.get("byline", ""), "LEAD_IMG": S.LEAD["img"],
         "LEAD_ALT": S.LEAD.get("alt", ""), "LEAD_BODY": paras(S.LEAD["body"]),
         "STORIES_1": [story(b) for b in S.BRIEFS[:3]],
         "STORIES_2": [story(dict(b, img="")) for b in S.BRIEFS[3:]],
         "HAS_PICKS": True, "PICKS": [story(p) for p in S.PICKS],
         "HAS_HEADLINES": True, "HEADLINES": rows(S.HEADLINES),
         "PROMO": dict(C.UCW), "AD1": banner(), "AD4": banner()}
    for n in (2, 3, 5, 6):
        d[f"AD{n}"] = text_ad(ads[n if n in ads else 2])
    return d


def sample_strings(kind):
    """Copy from the sample edition, none of which may survive in a template."""
    m = {"AM": C, "PM": P, "SP": S}[kind]
    out = []
    for item in [m.LEAD] + list(m.BRIEFS) + list(getattr(m, "PICKS", [])) + list(getattr(m, "WORTH", [])):
        out += [item["head"], item["url"], item["img"]]
        body = item.get("body", "")
        out += list(body) if isinstance(body, (list, tuple)) else [body]
    for row in list(getattr(m, "HEADLINES", [])) + list(getattr(m, "EARLIER", [])) + list(getattr(m, "PODCASTS", [])):
        out += [row[1], row[2]]
    for ad in getattr(m, "ADS", []):
        out += [ad["head"], ad["body"]]
    return [x for x in out if x]


JOBS = [("AM", "AR-Today-AM-template.html"),
        ("PM", "AR-Today-PM-template.html"),
        ("SP", "SubPrime-template.html")]

fail = 0
for kind, name in JOBS:
    tpl = (TPL / name).read_text(encoding="utf-8")
    slots = sorted({int(n) for n in re.findall(r"\{\{#AD(\d+)\}\}", tpl)})

    full = render(tpl, data_for(kind))
    empty = render(tpl, {k: v for k, v in data_for(kind).items()
                         if not re.fullmatch(r"AD\d+", k)})

    left = set(re.findall(r"\{\{[#^/]?\s*([\w.]+)\s*\}\}", full))
    sold = sum(1 for n in slots if f"AD {n} -" in full)
    unsold = sum(1 for n in slots if f"AD {n} -" in empty)
    opens, closes = full.count("<table"), full.count("</table>")
    eopens, ecloses = empty.count("<table"), empty.count("</table>")

    stale = [x[:60] for x in sample_strings(kind) if x in tpl]
    hard = sorted(set(re.findall(r'src="((?!\{\{)[^"]*)"', tpl)))
    hard = [h for h in hard if "icons8" not in h and "AR-lockup" not in h and "SP500" not in h
            and "logos/today-" not in h and "-masthead.png" not in h]
    banners = len(re.findall(r'\{\{img_desktop\}\}', tpl))
    mobiles = len(re.findall(r'\{\{img_mobile\}\}', tpl))
    print(f"   sample copy left: {stale or 'none'}")
    print(f"   hard-coded images beyond chrome: {hard or 'none'}")
    print(f"   banner images: desktop {banners}, mobile {mobiles}")
    ok = (not left) and sold == len(slots) and unsold == 0 \
        and opens == closes and eopens == ecloses \
        and not stale and not hard and banners == mobiles
    fail += not ok
    print(f"{name}")
    print(f"   ad slots {slots}  sold renders {sold}/{len(slots)}  unsold renders {unsold}")
    print(f"   unrendered fields: {sorted(left) or 'none'}")
    print(f"   tables balanced: filled {opens}/{closes}, no-ads {eopens}/{ecloses}")
    print(f"   size filled {len(full)//1024} kB, no-ads {len(empty)//1024} kB  -> "
          f"{'OK' if ok else 'FAIL'}")
    (SERVE / f"rendered-{kind}.html").write_text(full, encoding="utf-8")
    (SERVE / f"rendered-{kind}-noads.html").write_text(empty, encoding="utf-8")

print("\nfailures:", fail)
sys.exit(1 if fail else 0)
