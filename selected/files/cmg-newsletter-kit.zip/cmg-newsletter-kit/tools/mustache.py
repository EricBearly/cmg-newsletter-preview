"""A small Mustache subset, enough to render these templates and prove them.

Supports {{var}}, {{.}}, {{#section}}...{{/section}} over a hash (renders once),
a list (renders per item) or a boolean, and {{^section}} for the empty case.
Nothing is HTML-escaped: every value here is already markup or plain text that
belongs in markup, and escaping would mangle the &rsquo; entities the copy uses.

This exists so the templates can be rendered in a test rather than eyeballed.
Any real Mustache or Handlebars implementation renders them the same way.
"""
import re

TAG = re.compile(r"\{\{([#^/]?)\s*([\w.]+)\s*\}\}")


def _lookup(stack, name):
    if name == ".":
        # the implicit iterator: the current list item, which _merge stores
        # under "." so the surrounding context stays reachable by name
        top = stack[-1]
        return top.get(".") if isinstance(top, dict) and "." in top else top
    for frame in reversed(stack):
        if isinstance(frame, dict) and name in frame:
            return frame[name]
    return None


def render(template, data):
    out, stack = [], [data]
    i = 0
    while i < len(template):
        m = TAG.search(template, i)
        if not m:
            out.append(template[i:])
            break
        out.append(template[i:m.start()])
        sigil, name = m.group(1), m.group(2)
        if sigil in ("#", "^"):
            close = _find_close(template, m.end(), name)
            body = template[m.end():close[0]]
            val = _lookup(stack, name)
            if sigil == "#":
                if isinstance(val, list):
                    for item in val:
                        out.append(render(body, _merge(stack, item)))
                elif isinstance(val, dict):
                    out.append(render(body, _merge(stack, val)))
                elif val:
                    out.append(render(body, data))
            else:
                if not val:
                    out.append(render(body, data))
            i = close[1]
            continue
        if sigil == "/":
            raise ValueError(f"unexpected close tag {name}")
        val = _lookup(stack, name)
        out.append("" if val is None or val is False else str(val))
        i = m.end()
    return "".join(out)


def _merge(stack, frame):
    merged = {}
    for f in stack:
        if isinstance(f, dict):
            merged.update(f)
    if isinstance(frame, dict):
        merged.update(frame)
        merged.pop(".", None)      # a hash item is not the implicit iterator
    else:
        merged["."] = frame
    return merged


def _find_close(template, start, name):
    depth, i = 1, start
    while depth:
        m = TAG.search(template, i)
        if not m:
            raise ValueError(f"unclosed section {name}")
        if m.group(2) == name and m.group(1) in ("#", "^"):
            depth += 1
        elif m.group(2) == name and m.group(1) == "/":
            depth -= 1
            if depth == 0:
                return m.start(), m.end()
        i = m.end()
    raise ValueError(f"unclosed section {name}")


def render_list_items(template, data):
    """Render where a bare {{.}} stands for a string list item."""
    return render(template, data)
