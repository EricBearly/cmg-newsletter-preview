"""Rebuild every edition, capture, PDF and template, then run the checks.

Stops at the first failure. Starts its own local web server for Chrome to load
the emails from, and refuses to run if that port is already in use, because
another server would quietly serve someone else's files.
"""
import os, pathlib, socket, subprocess, sys, time

TOOLS = pathlib.Path(__file__).resolve().parent
PORT = int(os.environ.get("CMG_PORT", "8782"))

STEPS = [
    ["build_pm.py"],
    ["build_edition.py", "ar-canada", "bhph-report", "auto-fin-journal"],
    ["rebuild_six.py"],
    ["make_chosen_pdfs.py"],
    ["build_templates.py"],
    ["verify_templates.py"],
    ["audit_links.py"],
]

# --with-art also regenerates the AR Today masthead images first
if "--with-art" in sys.argv:
    STEPS.insert(0, ["make_lockup.py"])

with socket.socket() as s:
    if s.connect_ex(("127.0.0.1", PORT)) == 0:
        sys.exit(f"Port {PORT} is already in use. Set CMG_PORT to a free port.")

env = dict(os.environ, PYTHONIOENCODING="utf-8", CMG_PORT=str(PORT))
server = subprocess.Popen(
    [sys.executable, "-m", "http.server", str(PORT), "--bind", "127.0.0.1",
     "--directory", str(TOOLS / "serve")],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
try:
    for _ in range(50):
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", PORT)) == 0:
                break
        time.sleep(0.1)
    for step in STEPS:
        print(f"\n=== {' '.join(step)}", flush=True)
        result = subprocess.run([sys.executable, str(TOOLS / step[0]), *step[1:]], cwd=TOOLS, env=env)
        if result.returncode:
            sys.exit(f"\nFAILED at {step[0]}")
    print("\nAll steps passed. Now open newsletters/samples/ and look at the renders.")
finally:
    server.terminate()
