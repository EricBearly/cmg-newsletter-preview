"""Real Auto Fin Journal content, pulled 21 Oct 2026 from
autoremarketing.com/autofinjournal. Articles read before writing.
"""
BRAND = "Auto Fin Journal"
EDITION = "Mondays &amp; Wednesdays"
DATE = "Wednesday, Oct. 21, 2026"
TAGLINE = "How data and technology are impacting automotive"
HEADER_IMG = "img/AFJHeader.jpg"
SITE = "https://www.autoremarketing.com/autofinjournal/"

LEAD = {
    "cat": "Floorplan",
    "url": "https://www.autoremarketing.com/autofinjournal/shull-chosen-to-lead-first-business-banks-floorplan-operation/",
    "img": "img/afj-shull.jpg",
    "alt": "Drew Shull",
    "head": "Shull chosen to lead First Business Bank&rsquo;s floorplan operation",
    "deck": "The unit writes floorplan programs from about $1 million to more than $20 million",
    "byline": "Auto Fin Journal Staff &middot; 12:13 p.m.",
    "body": "Drew Shull has taken over as president of floorplan financing at First Business Specialty Finance, a "
            "First Business Bank subsidiary. He will lead the unit, which offers floorplan programs running from about "
            "$1 million to more than $20 million for larger, established independent dealers.",
}

BRIEFS = [
    {"cat": "People",
     "url": "https://www.autoremarketing.com/autofinjournal/dignifi-names-chief-product-officer/",
"img": "img/afj-brief0.jpg",
     "head": "DigniFi names chief product officer",
     "body": "Jefim Piekarz has been appointed to lead the product and engineering teams at the repair-financing "
             "fintech."},
    {"cat": "Lenders",
     "url": "https://www.autoremarketing.com/autofinjournal/latest-two-moves-by-u-s-bank-have-dealers-oems-in-mind/",
"img": "img/afj-brief1.jpg",
     "head": "Latest two moves by US Bank have dealers &amp; OEMs in mind",
     "body": "U.S. Bank announced two automotive-focused initiatives, among them redesigned BMW, MINI and BMW "
             "Motorrad credit cards."},
    {"cat": "Lenders",
     "url": "https://www.autoremarketing.com/autofinjournal/octane-hires-vp-of-sales-and-partnerships-to-sustain-strong-momentum-captive-as-a-service-program/",
"img": "img/afj-brief2.jpg",
     "head": "Octane hires VP of sales and partnerships to sustain captive-as-a-service momentum",
     "body": "The hire supports Octane&rsquo;s captive-as-a-service program, which brings together servicing, "
             "underwriting, technology and capital markets."},
]

WORTH = [
    {"cat": "Commentary",
     "url": "https://www.autoremarketing.com/autofinjournal/commentary-the-llm-compliance-paradox-separating-conversational-ai-from-quantitative-underwriting/",
"img": "img/afj-worth0.jpg",
     "head": "COMMENTARY: The LLM compliance paradox &amp; separating conversational AI from quantitative underwriting",
     "body": "Where large language models belong in a lending stack, and where they do not."},
    {"cat": "Commentary",
     "url": "https://www.autoremarketing.com/autofinjournal/commentary-calibrating-ai-risk-models-for-shifting-macroeconomic-cycles/",
"img": "img/afj-worth1.jpg",
     "head": "COMMENTARY: Calibrating AI risk models for shifting macroeconomic cycles",
     "body": "Keeping a risk model honest when the macro picture moves under it."},
    {"cat": "Technology",
     "url": "https://www.autoremarketing.com/autofinjournal/routeone-and-alfa-expand-integration-for-econtracting-leases/",
"img": "img/afj-worth2.jpg",
     "head": "RouteOne and Alfa expand integration for eContracting &amp; leases",
     "body": "Alfa earned certification for RouteOne&rsquo;s eContracting and lease integrations."},
]

PODCASTS = [
    ("Oct. 21", "https://www.autoremarketing.com/soundcloud_feed/used-car-week-hall-of-fame-grace-huang-of-cox-automotive/",
     "Used Car Week Hall of Fame: Grace Huang of Cox Automotive"),
    ("Oct. 20", "https://www.autoremarketing.com/soundcloud_feed/ben-sporn-of-vip-automotive-group-takes-diy-approach-to-ai/",
     "Ben Sporn of VIP Automotive Group Takes DIY Approach to AI"),
    ("Oct. 20", "https://www.autoremarketing.com/soundcloud_feed/sponsored-podcast-securing-the-vehicle-handoff-with-secure-vehicle-transfer/",
     "SPONSORED PODCAST: Securing the Vehicle Handoff with Secure Vehicle Transfer"),
    ("Oct. 13", "https://www.autoremarketing.com/soundcloud_feed/sponsored-episode-high-quality-used-inventory-via-the-service-drive-with-autohubs-dan-gaughan/",
     "SPONSORED EPISODE: High-quality used inventory via the service drive with AutoHub&rsquo;s Dan Gaughan"),
]
