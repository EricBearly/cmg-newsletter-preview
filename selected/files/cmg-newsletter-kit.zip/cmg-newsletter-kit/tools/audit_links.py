"""Fail if one story block links to two different articles.

A lead's url appears three times: headline, picture and Read more. A build that
rewrote only the first once left four editions pointing their pictures at the
wrong story, and nothing looked wrong on screen.
"""
import re, sys
from paths import BASE

FILES = [BASE / "versions" / f"{n}.html" for n in
         ("theme-blue-darkflag", "ar-today-pm", "ar-canada", "bhph-report", "auto-fin-journal")]
FILES.append(BASE / "subprime" / "versions" / "sp-blue-darkflag.html")
BLOCK = re.compile(r"(?:<!-- STORY[^>]*-->|<!-- =+\n\s*(?:3\. LEAD STORY|STORY \d+[^\n]*)\n\s*=+ -->)\n"
                   r"(.*?)\n</table>\n", re.S)
SECTIONS = ("/ar/", "/subprime/", "/arcanada/", "/bhph/", "/autofinjournal/")

bad = checked = 0
for f in FILES:
    for i, m in enumerate(BLOCK.finditer(f.read_text(encoding="utf-8")), 1):
        checked += 1
        links = {h for h in re.findall(r'href="(https?://[^"]+)"', m.group(1))
                 if any(s in h for s in SECTIONS)}
        if len(links) > 1:
            bad += 1
            print(f"{f.name} story block {i}: {sorted(links)}")
print(f"story blocks checked: {checked}, with mismatched links: {bad}")
sys.exit(1 if bad or not checked else 0)
